{- | Implementation note (BEA): For the sake of consistency, many
   functions return a result in a monad, even when the functions are
   completely pure. -}

module CoqLNOutputCommon where

import Text.Printf ( printf )

import AST
import ASTAnalysis
import MyLibrary ( sepStrings )


{- ----------------------------------------------------------------------- -}
{- * Constants: General -}

{- | The header for the generated output. -}

coqHeader :: String
coqHeader =
    "Require Export Coq.Program.Equality.\n\
    \Require Export Metatheory.\n\
    \Require Export LNgenFacts.\n\
    \Require Import Wf_nat.\n\
    \\n\
    \(** NOTE: Auxiliary theorems are hidden in generated documentation.\n\
    \    In general, there is a [_rec] version of every lemma involving\n\
    \    [open] and [close]. *)\n\
    \\n\
    \(** For generated HTML documentation. *)\n\
    \\n\
    \(** remove printing <= *)\n\
    \\n\
    \(** For proving the uniqueness of [lc] proofs. *)\n\
    \\n" ++
    printf
    "Axiom %s :\n\
    \  forall (A : Type) (B : A -> Type) (f g : forall x : A, B x),\n\
    \    (forall x, f x = g x) ->\n\
    \    f = g.\n\
    \\n"
    funExtEq

{- | Separator to use between parts of the generated output. -}

coqSep :: String
coqSep = "(* *********************************************************************** *)\n"

{- | The hint database for \"brute force\" automation. -}

bruteDb :: String
bruteDb = "brute_force"

{- | The name of the axiom asserting extensional equality on functions. -}

funExtEq :: String
funExtEq = "axiom_fun_ext_eq"

{- | The hint database for @lngen@ specific \"brute force\" automation
   via @auto@. -}

hintDb :: String
hintDb = "lngen"

{- | The name of the well-founded induction on natural numbers
   for @Set@. -}

ltWfRec :: String
ltWfRec = "lt_wf_rec"


{- ----------------------------------------------------------------------- -}
{- * Constants: Related to finite sets -}

{- | The default empty metavariable set. -}

mvSetEmpty :: String
mvSetEmpty = "empty"

{- | The default metavariable set type constructor. -}

mvSetType :: String
mvSetType = "fset"

{- | The default (infix) \"not in\" predicate on metavariable sets. -}

mvSetNotin :: String
mvSetNotin = "`notin`"

{- | The default (prefix) remove operation on metavariable sets. -}

mvSetRemove :: String
mvSetRemove = "remove"

{- | The default (prefix) singleton metavariable set constructor. -}

mvSetSingleton :: String
mvSetSingleton = "singleton"

{- | The default (infix) union operation on metavariable sets. -}

mvSetUnion :: String
mvSetUnion = "`union`"


{- ----------------------------------------------------------------------- -}
{- * Constants: Related to indices -}

{- | The type of bound variables (indices). -}

bvarType :: String
bvarType = "nat"

{- | The root to use for bound variables (indices). -}

bvarRoot :: String
bvarRoot = "n"

{- | The name of the \"less-than\" predicate on bound variables. -}

bvarLt :: String
bvarLt = "lt"

{- | The name of the \"lt_eq_lt_dec\" predicate on bound variables. -}

bvarLtEqLtDec :: String
bvarLtEqLtDec = "lt_eq_lt_dec"

{- | The name of the \"lt_ge_dec\" predicate on bound variables. -}

bvarLtGeDec :: String
bvarLtGeDec = "lt_ge_dec"


{- ----------------------------------------------------------------------- -}
{- * Constructing names: Metavariables and nonterminals -}

{- | Returns the canonical short name for the given metavariable root. -}

mvRoot :: Monad m => ASTAnalysis -> MvRoot -> m Name
mvRoot aa mv = return $ canonRoot aa mv

{- | Returns the canonical short name for the given nonterminal root. -}

ntRoot :: Monad m => ASTAnalysis -> NtRoot -> m Name
ntRoot aa nt = return $ canonRoot aa nt

{- | Returns the canonical type for the given metavariable root. -}

mvType :: Monad m => ASTAnalysis -> MvRoot -> m Name
mvType aa mv = getMvDecl aa mv >>= \decl -> return (toName decl)

{- | Returns the canonical type for the given nonterminal root. -}

ntType :: Monad m => ASTAnalysis -> NtRoot -> m Name
ntType aa nt = getSyntax aa nt >>= \decl -> return (toName decl)


{- ----------------------------------------------------------------------- -}
{- * Constructing names: Functions -}

{- | Returns the name of the @close@ function, where the function is
   defined by induction on the first given nonterminal. -}

closeName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
closeName aa nt1 mv2 =
    do { n1 <- ntRoot aa nt1
       ; m2 <- mvRoot aa mv2
       ; return $ "close_" ++ n1 ++ m2
       }

{- | Returns the name of the @close_rec@ function, where the function
   is defined by induction on the first given nonterminal. -}

closeRecName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
closeRecName aa nt1 mv2 =
    closeName aa nt1 mv2 >>= \n -> return $ n ++ "_rec"

{- | Returns the name of the @fv@ function, where the function is
   defined by induction on the first given nonterminal. -}

fvName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
fvName aa nt1 mv2 =
    do { n1 <- ntRoot aa nt1
       ; m2 <- mvRoot aa mv2
       ; return $ "fv_" ++ n1 ++ m2
       }

{- | Returns the name of the @open@ function, where the function is
   defined by induction on the first given nonterminal. -}

openName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
openName aa nt1 mv2 =
    do { n1 <- ntRoot aa nt1
       ; m2 <- mvRoot aa mv2
       ; return $ "open_" ++ n1 ++ m2
       }

{- | Returns the name of the @open_rec@ function, where the function
   is defined by induction the first given nonterminal. -}

openRecName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
openRecName aa nt1 mv2 =
    openName aa nt1 mv2 >>= \n -> return $ n ++ "_rec"

{- | Returns the name of the @size@ function. -}

sizeName :: Monad m => ASTAnalysis -> NtRoot -> m Name
sizeName aa nt = ntRoot aa nt >>= \n -> return $ "size_" ++ n

{- | Returns the name of the @subst@ function, where the function is
   defined by induction on the first given nonterminal. -}

substName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
substName aa nt1 mv2 =
    do { n1 <- ntRoot aa nt1
       ; m2 <- ntRoot aa mv2
       ; return $ "subst_" ++ n1 ++ m2
       }


{- ----------------------------------------------------------------------- -}
{- * Constructing names: Type classes -}

{- | The name of the type class for atoms. -}

atomClass :: String
atomClass = "Atom"

{- | The name of the @swap@ function on atoms. -}

swapAtomName :: String
swapAtomName = "swap_atom"

{- | The name of the type class for swapping. -}

swapClass :: String
swapClass = "Swap"

{- | The name of the @swap_distrib@ field. -}

swapDistrib :: String
swapDistrib = "swap_distrib"

{- | The hint database for the @Swap@ type class that includes
   distributivity. -}

swapDistribHintDb :: String
swapDistribHintDb = "swap_distrib"

{- | The hint database for the @Swap@ type class. -}

swapHintDb :: String
swapHintDb = "swap"

{- | Returns the name of @swap@ implementation function (not the name
   used in the type class's definition). -}

swapImplName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
swapImplName aa n m  =
    do { n'' <- (if n' `elem` ntRoots aa then ntRoot else mvRoot) aa n
       ; m'' <- (if m' `elem` ntRoots aa then ntRoot else mvRoot) aa m
       ; return $ swapName ++ "_" ++ n'' ++ m''
       }
    where
      n' = canonRoot aa n
      m' = canonRoot aa m

{- | The name of the @swap_invol@ field. -}

swapInvol :: String
swapInvol = "swap_invol"

{- | The name of the @swap@ function. -}

swapName :: String
swapName = "swap"

{- | The name of the @swap_same@ field. -}

swapSame :: String
swapSame = "swap_same"


{- ----------------------------------------------------------------------- -}
{- * Constructing names: Induction principles -}

{- | Takes a list of names of types and returns the name to use with a
   @Combined Scheme@ declarations for @Prop@. -}

mutIndName :: [Name] -> Name
mutIndName []  = error "mutIndName: Internal error."
mutIndName ns  = sepStrings "_" ns ++ "_mutind"

{- | Takes the name of a type and returns the name to use with a
   @Scheme@ declaration for @Prop@. -}

schemeIndName :: Name -> Name
schemeIndName = (++ "_ind'")

{- | Takes a list of names of types and returns the name to use with a
   @Combined Scheme@ declarations for @Set@. -}

mutRecName :: [Name] -> Name
mutRecName []  = error "mutRecName: Internal error."
mutRecName ns  = sepStrings "_" ns ++ "_mutrec"

{- | Takes the name of a type and returns the name to use with a
   @Scheme@ declaration for @Set@. -}

schemeRecName :: Name -> Name
schemeRecName = (++ "_rec'")

{- ----------------------------------------------------------------------- -}
{- * Constructing names: Predicates -}

{- | Returns the name of the @body@ predicate for the given
   nonterminal root, where the predicate is defined by induction on
   the first given nonterminal. -}

bodyName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
bodyName aa nt1 mv2 =
    do { n1 <- ntRoot aa nt1
       ; m2 <- ntRoot aa mv2
       ; return $ "body_" ++ n1 ++ m2
       }

{- | Returns the name of the degree predicate, where the predicate is
   defined by induction on the first given nonterminal. -}

degreeName :: Monad m => ASTAnalysis -> NtRoot -> MvRoot -> m Name
degreeName aa nt1 mv2 =
    do { n1 <- ntRoot aa nt1
       ; m2 <- ntRoot aa mv2
       ; return $ "degree_" ++ n1 ++ m2
       }

{- | Returns the name of the degree constructor, where the predicate
   is defined by induction on the first given nonterminal. -}

degreeConstrName :: Monad m => ASTAnalysis -> SConstr -> NtRoot -> NtRoot -> m Name
degreeConstrName aa sc nt1 nt2 =
    degreeName aa nt1 nt2 >>= \n -> return $ n ++ "_" ++ toShortName sc

{- | Returns the name of the local closure predicate for the given
   nonterminal. -}

lcName :: Monad m => ASTAnalysis -> NtRoot -> m Name
lcName aa nt = ntRoot aa nt >>= \n -> return $ "lc_" ++ n

{- | Returns the name of the local closure "universal" constructor for
   the given constructor, which is assumed to be for the given
   nonterminal. -}

lcConstrName :: Monad m => ASTAnalysis -> SConstr -> NtRoot -> m Name
lcConstrName aa sc nt =
    lcName aa nt >>= \n -> return $ n ++ "_" ++ toShortName sc

{- | Returns the name of the local closure "exists" constructor for
   the given constructor, which is assumed to be for the given
   nonterminal. -}

lcExConstrName :: Monad m => ASTAnalysis -> SConstr -> NtRoot -> m Name
lcExConstrName aa sc nt =
    lcName aa nt >>= \n -> return $ n ++ "_" ++ toShortName sc ++ "_ex"


{- ----------------------------------------------------------------------- -}
{- * Constructing names: Tactics -}

{- | The name of the tactic for applying a mutual induction principle. -}

applyMutInd :: String
applyMutInd = "apply_mutual_ind"

{- | The name of the default @auto@ tactic. -}

defaultAuto :: String
defaultAuto = "default_auto"

{- | The name of the default @autorewrite@ tactic. -}

defaultAutoRewr :: String
defaultAutoRewr = "default_autorewrite"

{- | The name of the default simplification tactic. -}

defaultSimp :: String
defaultSimp = "default_simp"

{- | The name of the default simplification tactic that doesn't do
   case analysis. -}

defaultSteps :: String
defaultSteps = "default_steps"

{- | The name of the tactic for using @eapply@ to apply the first
   applicable hypothesis. -}

eapplyFirst :: String
eapplyFirst = "eapply_first_hyp"

{- | The general purpose tactic for solving goals about finite sets. -}

fsetdecTac :: String
fsetdecTac = "fsetdec"

{- | The name of the @gather@ tactic for the given type. -}

gatherTac :: Name -> String
gatherTac n = "gather_" ++ n ++ "s"

{- | The name of the @pick_fresh@ tactic for the given type. -}

pickFreshTac :: Name -> String
pickFreshTac n = "pick_fresh_" ++ n

{- | The name for the tactic that simplifies a list of atom sets. -}

simplGatherTac :: String
simplGatherTac = "simplify_list_of_atom_sets"
