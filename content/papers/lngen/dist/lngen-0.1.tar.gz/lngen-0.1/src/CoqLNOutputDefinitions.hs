{- | Implementation notes (BEA): The exported function expect that the
   given list of 'NtRoot's all be canonical and correspond to a
   collection of mutually declared non-terminals. -}

module CoqLNOutputDefinitions
    ( processClose
    , processDegree
    , processFv
    , processLc
    , processMv
    , processNt
    , processOpen
    , processPhantom
    , processSize
    , processSubst
    , processTactics
    ) where

import Data.List   ( nub )
import Text.Printf ( printf )

import AST
import ASTAnalysis
import ComputationMonad
import CoqLNOutputCombinators
import CoqLNOutputCommon
import MyLibrary ( mapMM, sepStrings )


{- ----------------------------------------------------------------------- -}
{- * Assorted helper functions -}

{- | Constructs the @Scheme@ declarations for the given list of types
   at the sort @Prop@. -}

schemeIndDecl :: [Name] -> Int -> M Name
schemeIndDecl ns i =
    do { hyps <- sequence $ take (i + length ns) $ repeat (newName "H")
       ; let args  = sepStrings " " hyps
       ; let calls = map (\s -> s ++ " " ++ args) $ map schemeIndName ns
       ; return $ printf
         "Scheme %s.\n\
         \\n\
         \Definition %s :=\n\
         \  fun %s =>\n\
         \  %s.\n\
         \\n"
         (sepStrings "\n  with " (map f ns))
         (mutIndName ns) args (foldr1 join calls)
       }
    where
      join = printf "(conj (%s)\n  (%s))"

      f n = printf "%s := Induction for %s Sort Prop" (schemeIndName n) n

{- | Constructs the @Scheme@ declarations for the given list of types
   at the sort @Set@. -}

schemeRecDecl :: [Name] -> Int -> M Name
schemeRecDecl ns i =
    do { hyps <- sequence $ take (i + length ns) $ repeat (newName "H")
       ; let args  = sepStrings " " hyps
       ; let calls = map (\s -> s ++ " " ++ args) $ map schemeRecName ns
       ; return $ printf
         "Scheme %s.\n\
         \\n\
         \Definition %s :=\n\
         \  fun %s =>\n\
         \  %s.\n\
         \\n"
         (sepStrings "\n  with " (map f ns))
         (mutRecName ns) args (foldr1 join calls)
       }
    where
      join = printf "(pair (%s)\n  (%s))"

      f n = printf "%s := Induction for %s Sort Set" (schemeRecName n) n


{- ----------------------------------------------------------------------- -}
{- * Output for \"close\" -}

{- | Generates the text for the @close@ and @close_rec@ functions. -}

processClose :: ASTAnalysis -> [NtRoot] -> M String
processClose aa nts =
    do { s1 <- processCloseRecs aa nts
       ; s2 <- processCloseDefs aa nts
       ; return $ s1 ++ s2
       }

{- | Generates the text for the definitions of @close@. -}

processCloseDefs :: ASTAnalysis -> [NtRoot] -> M String
processCloseDefs aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ concat ss
       }
    where
      f aa nt1 _ mv2 =
          do { fn    <- closeName aa nt1 mv2
             ; fnrec <- closeRecName aa nt1 mv2
             ; e     <- newName nt1
             ; x     <- newName mv2
             ; return $ printf
               "Definition %s %s %s := %s 0 %s %s.\n\n"
               fn x e fnrec x e
             }

{- | Generates the text for the definitions of @close_rec@. -}

processCloseRecs :: ASTAnalysis -> [NtRoot] -> M String
processCloseRecs aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ map join $ ss
       }
    where
      join strs = printf "Fixpoint %s.\n\n" (sepStrings "\n\nwith " strs)

      f aa nt1 nt2 mv2 =
        do { close           <- closeRecName aa nt1 mv2
           ; k               <- newName bvarRoot
           ; x               <- newName mv2
           ; xtype           <- mvType aa mv2
           ; e               <- newName nt1
           ; etype           <- ntType aa nt1
           ; (Syntax _ _ cs) <- getSyntax aa nt1
           ; branches        <- mapM (local . branch k x nt1 nt2 mv2) cs
           ; return $ printf
             "%s (%s : %s) (%s : %s) (%s : %s) {struct %s} : %s :=\n\
             \  match %s with\n\
             \%s\n\
             \  end"
             close k bvarType x xtype e etype e etype
             e
             (sepStrings "\n" branches)
            }


      branch k _ nt1 nt2 mv2 c@(SConstr _ _ _ _ (Bound mv'))
          | canonRoot aaa nt1 == canonRoot aaa nt2 &&
            canonRoot aaa mv2 == canonRoot aaa mv' =
                do { n <- newName bvarRoot
                   ; return $ printf
                     "    | %s %s => if (%s %s %s) then (%s %s) else (%s %s)"
                     (toName c) n
                     bvarLtGeDec n k
                     (toName c) n
                     (toName c) ("(S " ++ n ++ ")")
                   }
      branch k x nt1 nt2 mv2 c@(SConstr _ _ _ _ (Free mv'))
                | canonRoot aaa nt1 == canonRoot aaa nt2 &&
                  canonRoot aaa mv2 == canonRoot aaa mv' =
              do { y   <- newName mv2
                 ; bsc <- getBoundVarConstr aaa nt1 mv2
                 ; return $ printf
                   "    | %s %s => if (%s == %s) then (%s %s) else (%s %s)"
                   (toName c) y
                   x y
                   (toName bsc) k
                   (toName c) y
                 }
      branch k x nt1 nt2 mv2 c@(SConstr _ _ _ ts _) =
          do { args  <- mapM (newName . toRoot) ts
             ; calls <- mapM (call k x nt1 nt2 mv2) (zip ts args)
             ; return $ printf
               "    | %s%s => %s%s"
               (toName c)
               (sepStrings " " ("" : args))
               (toName c)
               (sepStrings " " ("" : calls))
             }

      call _ _ _ _ _ (IndexArg, z) = return z
      call _ _ _ _ _ (MvArg _,  z) = return z

      call k x _ nt2 mv2 (NtArg nt, z)
          | canBindIn aaa nt2 nt =
              do { fn <- closeRecName aaa nt mv2
                 ; return $ printf "(%s %s %s %s)" fn k x z
                 }
          | otherwise =
              return z

      call k x nt1 nt2 mv2 (BindingArg mv' ntm nt, z)
          | canonRoot aaa ntm == canonRoot aaa nt2 &&
            canonRoot aaa mv2 == canonRoot aaa mv' =
                do { fn <- closeRecName aaa nt mv2
                   ; return $ printf
                     "(%s %s %s %s)"
                     fn ("(S " ++ k ++ ")") x z
                   }
          | otherwise =
              call k x nt1 nt2 mv2 (NtArg nt, z)


{- ----------------------------------------------------------------------- -}
{- * Output for degree -}

{- | Generates the text for the @degree@ predicates. -}

processDegree :: ASTAnalysis -> [NtRoot] -> M String
processDegree aa nts =
    do { s1 <- processDegreeDefs aa nts
       ; s2 <- processDegreeSchemes aa nts
       ; s3 <- processDegreeHints aa nts
       ; return $ s1 ++ s2 ++ s3
       }

{- | Generates the @Scheme@ declarations for @degree@. -}

processDegreeSchemes :: ASTAnalysis -> [NtRoot] -> M String
processDegreeSchemes aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; countss <- processNt1Nt2Mv2 aaa nt1s count
       ; let counts = map sum countss
       ; s1 <- mapM (\(n,i) -> local $ schemeIndDecl n i) (zip ss counts)
       ; s2 <- mapM (\(n,i) -> local $ schemeRecDecl n i) (zip ss counts)

       ; return $ concat s1 ++ concat s2
       }
    where
      f aa nt1 _ mv2 = degreeName aa nt1 mv2

      count aa nt1 _ _ =
          do { (Syntax _ _ cs) <- getSyntax aa nt1
             ; return $ length cs
             }

{- | Generates the @Hint@ declarations for the @degree@ predicates. -}

processDegreeHints :: ASTAnalysis -> [NtRoot] -> M String
processDegreeHints aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ concat $ ss
       }
    where
      f aa nt1 _ mv2 =
          do { name <- degreeName aa nt1 mv2
             ; return $ printf
               "Hint Constructors %s : core %s.\n\n"
               name hintDb
             }

{- | Generates the text for the @degree@ predicates. -}

processDegreeDefs :: ASTAnalysis -> [NtRoot] -> M String
processDegreeDefs aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ map join ss
       }
    where
      join strs = printf "Inductive %s.\n\n" (sepStrings "\n\nwith " strs)

      f aa nt1 nt2 mv2 =
          do { (Syntax _ _ cs) <- getSyntax aa nt1
             ; degname         <- degreeName aa nt1 mv2
             ; nttype          <- ntType aa nt1
             ; cs'             <- mapM (local . constr nt1 nt2 mv2) cs
             ; return $ printf
               "%s : %s -> %s -> Set :=\n\
               \%s"
               degname bvarType nttype
               (sepStrings "\n" cs')
             }

      constr nt1 nt2 mv2 c@(SConstr _ _ _ _ (Bound mv'))
          | canonRoot aaa nt1 == canonRoot aaa nt2 &&
            canonRoot aaa mv2 == canonRoot aaa mv' =
                do { deg        <- degreeName aaa nt1 mv2
                   ; deg_constr <- degreeConstrName aaa c nt1 mv2
                   ; n          <- newName bvarRoot
                   ; i          <- newName bvarRoot
                   ; return $ printf
                     "  | %s : forall %s %s,\n\
                     \    %s %s %s ->\n\
                     \    %s %s (%s %s)"
                     deg_constr n i
                     bvarLt i n
                     deg n (toName c) i
                   }
      constr nt1 nt2 mv2 c@(SConstr _ _ _ ts _) =
          do { deg        <- degreeName aaa nt1 mv2
             ; deg_constr <- degreeConstrName aaa c nt1 mv2
             ; n          <- newName bvarRoot
             ; args       <- mapM (newName . toRoot) ts
             ; hyps       <- mapMM (hyp n nt1 nt2 mv2) (zip ts args)
             ; return $ printf
               "  | %s : forall %s,\n\
               \%s\
               \    %s %s (%s%s)"
               deg_constr (sepStrings " " (n : args))
               (concat hyps :: String)
               deg n (toName c) (sepStrings " " ("" : args))
             }

      hyp _ _ _ _ (IndexArg , _) = return Nothing
      hyp _ _ _ _ (MvArg _,   _) = return Nothing

      hyp n _ nt2 mv2 (NtArg ntr, arg)
          | canBindIn aaa nt2 ntr =
              do { deg <- degreeName aaa ntr mv2
                 ; return $ Just $ printf
                   "    %s %s %s ->\n"
                   deg n arg
                 }
          | otherwise =
              return Nothing

      hyp n nt1 nt2 mv2 (BindingArg mv' nt' nt'', arg)
          | canonRoot aaa nt' == canonRoot aaa nt2 &&
            canonRoot aaa mv2 == canonRoot aaa mv' =
              hyp ("(S " ++ n ++")") nt1 nt2 mv2 (NtArg nt'', arg)
          | otherwise =
              hyp n nt1 nt2 mv2 (NtArg nt'', arg)


{- ----------------------------------------------------------------------- -}
{- * Output for \"fv\" -}

{- Generates the text for the @fv@ functions. -}

processFv :: ASTAnalysis -> [NtRoot] -> M String
processFv aa nts =
    do { s1 <- processFvDefs aa nts
       ; return $ s1
       }

{- Generates the text for the @fv@ functions. -}

processFvDefs :: ASTAnalysis -> [NtRoot] -> M String
processFvDefs aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ map join ss
       }
    where
      join strs = printf "Fixpoint %s.\n\n" (sepStrings "\n\nwith " strs)

      f aa nt1 nt2 mv2 =
          do { fv_fn           <- fvName aa nt1 mv2
             ; e               <- newName nt1
             ; etype           <- ntType aa nt1
             ; mvt             <- mvType aa mv2
             ; (Syntax _ _ cs) <- getSyntax aa nt1
             ; branches        <- mapM (local . branch nt1 nt2 mv2) cs
             ; return $ printf
               "%s (%s : %s) {struct %s} : %s %s :=\n\
               \  match %s with\n\
               \%s\n\
               \  end"
               fv_fn e etype e mvSetType mvt
               e
               (sepStrings "\n" branches)
             }

      branch nt1 nt2 mv2 c@(SConstr _ _ _ ts _) =
          do { args   <- mapM (newName . toRoot) ts
             ; calls' <- mapMM (call nt1 nt2 mv2) (zip ts args)
             ; let calls = if null calls' then [mvSetEmpty] else calls'
             ; return $ printf
               "    | %s%s => %s"
               (toName c)
               (sepStrings " " ("" : args))
               (sepStrings (" " ++ mvSetUnion ++ " ") calls)
             }

      call _   _   _   (IndexArg, _)          = return Nothing
      call nt1 nt2 mv2 (BindingArg _ _ nt, x) = call nt1 nt2 mv2 (NtArg nt, x)

      call _ _ mv2 (MvArg mv', x)
          | canonRoot aaa mv2 == canonRoot aaa mv' =
              return $ Just $ printf "(%s %s)" mvSetSingleton x
          | otherwise =
              return Nothing

      call _ nt2 mv2 (NtArg nt, x)
          | canBindIn aaa nt2 nt =
              do { fn <- fvName aaa nt mv2
                 ; return $ Just $ printf "(%s %s)" fn x
                 }
          | otherwise =
              return Nothing


{- ----------------------------------------------------------------------- -}
{- * Output for local closure -}

{- | Generates text for the definitions of @lc@. -}

processLc :: ASTAnalysis -> [NtRoot] -> M String
processLc aa nts' =
    do { let nts = filter (isOpenable aa) nts'
       ; defs      <- mapM def nts
       ; names     <- mapM (lcName aa) nts
       ; counts    <- mapM count nts
       ; indScheme <- local $ schemeIndDecl names (sum counts)
       ; recScheme <- local $ schemeRecDecl names (sum counts)
       ; if null defs
         then return ""
         else return $ printf
              "Inductive %s.\n\
              \\n\
              \%s\
              \%s\
              \%s"
              (sepStrings "\n\nwith " defs)
              indScheme
              recScheme
              (concat (map hint names) :: String)
       }
    where
      count nt1 =
          do { (Syntax _ _ cs) <- getSyntax aa nt1
             ; return $ length $ filter isCountable cs
             }

      isCountable (SConstr _ _ _ _ (Bound _)) = False
      isCountable (SConstr _ _ _ _ _)         = True

      hint = \s -> printf "Hint Constructors %s : core %s.\n\n" s hintDb

      def :: NtRoot -> M String
      def nt =
          do { (Syntax _ _ cs) <- getSyntax aa nt
             ; lcname          <- lcName aa nt
             ; nttype          <- ntType aa nt
             ; cs'             <- mapMM (local . constr nt) cs
             ; return $ printf
               "%s : %s -> Set :=\n\
               \%s"
               lcname nttype
               (sepStrings "\n" cs')
             }

      constr _  (SConstr _ _ _ _ (Bound _)) = return Nothing
      constr nt c@(SConstr _ _ _ ts _)  =
        do { lc        <- lcName aa nt
           ; lc_constr <- lcConstrName aa c nt
           ; args      <- mapM (newName . toRoot) ts
           ; hyps      <- mapMM hyp (zip ts args)
           ; return $ Just $ printf
             "  | %s :%s\n\
             \%s\
             \    %s (%s%s)"
             lc_constr (forallPrefix args)
             (concat hyps :: String)
             lc (toName c) (sepStrings " " ("" : args))
           }
          where
            forallPrefix [] = ""
            forallPrefix xs = " forall " ++ (sepStrings " " xs) ++ ","

            hyp (IndexArg, _) = return Nothing
            hyp (MvArg _,  _) = return Nothing

            hyp (NtArg ntr, arg)
                | isOpenable aa ntr =
                    do { lc <- lcName aa ntr
                       ; return $ Just $ printf "    %s %s ->\n" lc arg
                       }
                | otherwise =
                    return Nothing

            hyp (BindingArg mv1 nt1 nt2, arg) =
                do { x        <- newName mv1
                   ; xtype    <- mvType aa mv1
                   ; lc       <- lcName aa nt2
                   ; open_fn  <- openName aa nt2 mv1
                   ; fvconstr <- getFreeVarConstr aa nt1 mv1
                   ; return $ Just $ printf
                     "    (forall %s : %s, %s (%s (%s %s) %s)) ->\n"
                     x xtype
                     lc
                     open_fn (toName fvconstr) x arg
                   }


{- ----------------------------------------------------------------------- -}
{- * Output for metavariables -}

{- | Generates text for metavariable declarations. -}

processMv :: ASTAnalysis -> MvRoot -> M String
processMv aa mv =
    do { mvd  <- getMvDecl aa mv
       ; name <- mvType aa mv
       ; return $ printf "Notation %s := (%s).\n\n" name (coqMvImplType mvd)
       }


{- ----------------------------------------------------------------------- -}
{- * Output for nonterminals -}

{- | Generates text for nonterminal declarations. -}

processNt :: ASTAnalysis -> [NtRoot] -> M String
processNt aa nts =
    do { defs      <- mapM (coreNtText aa) nts
       ; names     <- mapM (ntType aa) nts
       ; counts    <- mapM count nts
       ; schemeInd <- local $ schemeIndDecl names (sum counts)
       ; schemeRec <- local $ schemeRecDecl names (sum counts)
       ; return $ printf
         "Inductive %s.\n\
         \\n\
         \%s\
         \%s"
         (sepStrings "\n\nwith " defs)
         schemeInd
         schemeRec
       }
    where
      count nt1 =
          do { (Syntax _ _ cs) <- getSyntax aa nt1
             ; return $ length cs
             }

{- | Generates the \"core\" text for nonterminal declarations. -}

coreNtText :: ASTAnalysis -> NtRoot -> M String
coreNtText aa nt =
    do { t               <- ntType aa nt
       ; (Syntax _ _ cs) <- getSyntax aa nt
       ; cs'             <- mapM constr cs
       ; return $ t ++ " : Set :=\n" ++ sepStrings "\n" cs'
       }
    where
      constr c@(SConstr _ _ _ ts _) =
          do { args   <- mapM text ts
             ; result <- ntType aa nt
             ; return $ "  | " ++ (toName c) ++ " : " ++
                        sepStrings " -> " (args ++ [result])
             }

      text (IndexArg)         = return bvarType
      text (MvArg x)          = mvType aa x
      text (NtArg x)          = ntType aa x
      text (BindingArg _ _ x) = ntType aa x


{- ----------------------------------------------------------------------- -}
{- * Output for \"open\" -}

{- | Generates the text for the @open@ and @open_rec@ functions. -}

processOpen :: ASTAnalysis -> [NtRoot] -> M String
processOpen aa nts =
    do { s1 <- processOpenRecs aa nts
       ; s2 <- processOpenDefs aa nts
       ; return $ s1 ++ s2
       }

{- | Generates the text for the definitions of @open@. -}

processOpenDefs :: ASTAnalysis -> [NtRoot] -> M String
processOpenDefs aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ concat $ ss
       }
    where
      f aa nt1 nt2 mv2 =
          do { fn    <- openName aa nt1 mv2
             ; fnrec <- openRecName aa nt1 mv2
             ; e     <- newName nt1
             ; u     <- newName nt2
             ; return $ printf
               "Definition %s %s %s := %s 0 %s %s.\n\n"
               fn u e fnrec u e
             }

{- | Generates the text for the definitions of @open_rec@. -}

processOpenRecs :: ASTAnalysis -> [NtRoot] -> M String
processOpenRecs aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ map join ss
       }
    where
      join strs = printf "Fixpoint %s.\n\n" (sepStrings "\n\nwith " strs)

      f aa nt1 nt2 mv2 =
          do { open_fn         <- openRecName aa nt1 mv2
             ; k               <- newName bvarRoot
             ; u               <- newName nt2
             ; utype           <- ntType aa nt2
             ; e               <- newName nt1
             ; etype           <- ntType aa nt1
             ; (Syntax _ _ cs) <- getSyntax aa nt1
             ; branches        <- mapM (local . branch nt1 nt2 mv2 k u) cs
             ; return $ printf
               "%s (%s : %s) (%s : %s) (%s : %s) {struct %s} : %s :=\n\
               \  match %s with\n\
               \%s\n\
               \  end"
               open_fn k bvarType u utype e etype e etype
               e
               (sepStrings "\n" branches)
             }

      branch nt1 nt2 mv2 k u c@(SConstr _ _ _ _ (Bound mv'))
          | canonRoot aaa nt1 == canonRoot aaa nt2 &&
            canonRoot aaa mv2 == canonRoot aaa mv' =
                do { n <- newName bvarRoot
                   ; return $ printf
                     "    | %s %s =>\n\
                     \      match %s %s %s with\n\
                     \        | inleft (left _)  => %s %s\n\
                     \        | inleft (right _) => %s\n\
                     \        | inright _        => %s (%s - 1)\n\
                     \      end"
                     (toName c) n
                     bvarLtEqLtDec n k
                     (toName c) n
                     u
                     (toName c) n
                   }
      branch nt1 nt2 mv2 k u c@(SConstr _ _ _ ts _) =
          do { args  <- mapM (newName . toRoot) ts
             ; calls <- mapM (call k u nt1 nt2 mv2) (zip ts args)
             ; return $ printf
               "    | %s%s => %s%s"
               (toName c)
               (sepStrings " " ("" : args))
               (toName c)
               (sepStrings " " ("" : calls))
             }

      call _ _ _ _ _ (IndexArg, x) = return x
      call _ _ _ _ _ (MvArg _,  x) = return x

      call k u _ nt2 mv2 (NtArg nt, x)
          | canBindIn aaa nt2 nt =
              do { fn <- openRecName aaa nt mv2
                 ; return $ printf "(%s %s %s %s)" fn k u x
                 }
          | otherwise =
              return x

      call k u nt1 nt2 mv2 (BindingArg mv' ntm nt, x)
          | canonRoot aaa ntm == canonRoot aaa nt2 &&
            canonRoot aaa mv2 == canonRoot aaa mv' =
                do { fn <- openRecName aaa nt mv2
                   ; let k' = "(S " ++ k ++ ")"
                   ; return $ printf "(%s %s %s %s)" fn k' u x
                   }
          | otherwise =
              call k u nt1 nt2 mv2 (NtArg nt, x)


{- ----------------------------------------------------------------------- -}
{- * Output for phantoms -}

{- | Generates text for phantom metavariable declarations. -}

processPhantom :: ASTAnalysis -> MvRoot -> M String
processPhantom aa mv =
    do { name <- mvType aa mv
       ; return $ printf "Parameter %s : Set.\n\n" name
       }


{- ----------------------------------------------------------------------- -}
{- * Output for size -}

{- | Generates the text for the @size@ functions. -}

processSize :: ASTAnalysis -> [NtRoot] -> M String
processSize aa nts =
    do { defs <- mapM (local . def) nts
       ; return $ printf "Fixpoint %s.\n\n" (sepStrings "\n\nwith " defs)
       }
    where
      def nt =
          do { size_fn         <- sizeName aa nt
             ; e               <- newName nt
             ; etype           <- ntType aa nt
             ; (Syntax _ _ cs) <- getSyntax aa nt
             ; branches        <- mapM (local . branch) cs
             ; return $ printf
               "%s (%s : %s) {struct %s} : nat :=\n\
               \  match %s with\n\
               \%s\n\
               \  end"
               size_fn e etype e
               e
               (sepStrings "\n" branches)
             }

      branch c@(SConstr _ _ _ ts _) =
          do { args  <- mapM (newName . toRoot) ts
             ; calls <- mapMM call (zip ts args)
             ; return $ printf "    | %s%s => 1%s"
                      (toName c)
                      (sepStrings " " ("" : args))
                      (sepStrings " + " ("" : calls))
             }

      call (IndexArg,          _) = return Nothing
      call (MvArg _,           _) = return Nothing
      call (BindingArg _ _ nt, z) = call (NtArg nt, z)

      call (NtArg nt, z) =
          do { fn <- sizeName aa nt
             ; return $ Just $ printf "(%s %s)" fn z
             }


{- ----------------------------------------------------------------------- -}
{- * Output for substitution -}

{- | Generates text for the @subst@ functions. -}

processSubst :: ASTAnalysis -> [NtRoot] -> M String
processSubst aaa nt1s =
    do { ss <- processNt1Nt2Mv2 aaa nt1s f
       ; return $ concat $ map join ss
       }
    where
      join strs = printf "Fixpoint %s.\n\n" (sepStrings "\n\nwith " strs)

      f aa nt1 nt2 mv2 =
          do { subst_fn        <- substName aa nt1 mv2
             ; x               <- newName mv2
             ; xtype           <- mvType aa mv2
             ; u               <- newName nt2
             ; utype           <- ntType aa nt2
             ; e               <- newName nt1
             ; etype           <- ntType aa nt1
             ; (Syntax _ _ cs) <- getSyntax aa nt1
             ; branches        <- mapM (local . branch nt1 nt2 mv2 x u) cs
             ; return $ printf
               "%s (%s : %s) (%s : %s) (%s : %s) {struct %s} : %s :=\n\
               \  match %s with\n\
               \%s\n\
               \  end"
               subst_fn u utype x xtype e etype e etype
               e
               (sepStrings "\n" branches)
             }

      branch nt1 nt2 mv2 x u c@(SConstr _ _ _ _ (Free mv'))
          | canonRoot aaa nt1 == canonRoot aaa nt2 &&
            canonRoot aaa mv2 == canonRoot aaa mv' =
                do { y   <- newName mv2
                   ; return $ printf
                     "    | %s %s => if (%s == %s) then (%s) else (%s %s)"
                     (toName c) y
                     x y
                     u
                     (toName c) y
                   }
      branch _ nt2 mv2 x u c@(SConstr _ _ _ ts _) =
          do { args  <- mapM (newName . toRoot) ts
             ; calls <- mapM call (zip ts args)
             ; return $ printf
               "    | %s%s => %s%s"
               (toName c)
               (sepStrings " " ("" : args))
               (toName c)
               (sepStrings " " ("" : calls))
             }
          where
            call (IndexArg,          z) = return z
            call (MvArg _,           z) = return z

            call (BindingArg _ _ nt, z) = call (NtArg nt, z)

            call (NtArg nt, z)
                | canBindIn aaa nt2 nt =
                    do { fn <- substName aaa nt mv2
                       ; return $ printf "(%s %s %s %s)" fn u x z
                       }
                | otherwise =
                    return z


{- ----------------------------------------------------------------------- -}
{- * Tactic support -}

{- | Generates the text for all supporting tactics. -}

processTactics :: ASTAnalysis -> M String
processTactics aa =
    do { strs <- mapM (local . processTacticMv aa) uimpls
       ; return $ printf
         "(** Tactic definitions. *)\n\
         \\n\
         \%s\
         \(** Additional hint declarations. *)\n\
         \\n\
         \Hint Resolve @plus_le_compat : %s. (* from Coq.Arith.Plus *)\n\
         \\n\
         \(** Redefine [%s] and [%s]. *)\n\
         \\n\
         \Ltac %s ::= auto with arith set %s %s.\n\
         \Ltac %s ::= autorewrite with %s in *.\n\
         \\n"
         (concat strs)
         hintDb
         defaultAuto defaultAutoRewr
         defaultAuto bruteDb hintDb
         defaultAutoRewr hintDb
       }
    where
      uimpls  = nub $ concat $ mapM f (mvRoots aa)
      f mv    = do { mvd <- getMvDecl aa mv
                   ; return $ coqMvImplType mvd
                   }

{- | Generates the text for a given metavariable implementation type. -}

processTacticMv :: ASTAnalysis -> Name -> M String
processTacticMv aa n =
    do { s1 <- newName "S"
       ; s2 <- newName "S"
       ; let fv1 = printf "  let %s := ltac_map (fun x : %s => %s x) in\n"
                          s1 n mvSetSingleton
       ; let fv2 = printf "  let %s := ltac_map (fun x : %s %s => x) in\n"
                          s2 mvSetType n

       ; rawFvs <- fvGathers
       ; picks  <- mapMM pick (mvRoots aa)
       ; let (fvs, names) = unzip rawFvs

       ; return $ printf
         "Ltac %s :=\n\
         \%s\
         \  %s (%s).\n\
         \\n\
         \%s"
         (gatherTac n)
         (fv1 ++ fv2 ++ concat fvs :: String)
         simplGatherTac (sepStrings " ++ " (s1:s2:names))
         (concat picks :: String)
       }
    where
      fvGathers =
          do { let nt1s   = filter (isOpenable aa) (ntRoots aa)
             ; let nt2s   = ntRoots aa
             ; let tuples = [(x,y,z) | x <- nt1s
                                     , y <- nt2s
                                     , canBindIn aa y x
                                     , z <- mvsOfNt aa y]
             ; mapMM fvGather tuples
             }

      fvGather (nt1, _, mv2) =
          do { fv      <- fvName aa nt1 mv2
             ; mvd     <- getMvDecl aa mv2
             ; s       <- newName "S"
             ; nt1type <- ntType aa nt1
             ; if n == coqMvImplType mvd
               then return $ Just $
                        ( printf
                          "  let %s := ltac_map (fun x : %s => %s x) in\n"
                          s nt1type fv
                        , s
                        )
               else return Nothing
             }

      pick mv =
          do { mvd <- getMvDecl aa mv
             ; mvt <- mvType aa mv
             ; if coqMvImplType mvd == n
               then return $ Just $ printf
                        "Ltac %s x :=\n\
                        \  let L := %s in\n\
                        \  (pick fresh x for L).\n\
                        \\n\
                        \Tactic Notation \"pick\" \"fresh\" \"%s\" ident(x) :=\n\
                        \  let L := %s in\n\
                        \  (pick fresh x for L).\n\
                        \\n"
                        (pickFreshTac mvt)
                        (gatherTac n)
                        mvt
                        (gatherTac n)
               else return Nothing
             }
