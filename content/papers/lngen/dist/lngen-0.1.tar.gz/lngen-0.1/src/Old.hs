{-# OPTIONS_GHC -fcontext-stack=50 #-}

module CoqLNOutputTheorems
    ( processDegreeThms
    , processLcThms
    , processOpenLcThms
    , processSizeThms
    , processSizeCloseThms
    , processSizeOpenRecThms
    , processSubstThms
    , processSubstOpenThms
    , processSwapThms
    , processSwapInstThms
    ) where

import Text.Printf ( printf )

import AST
import ASTAnalysis
import ComputationMonad
import CoqLNOutputCommon
import MyLibrary ( sepStrings )


{- ----------------------------------------------------------------------- -}
{- XXX OLD CODE -}

-- XXX BEA: lemmaHintText (and friends) ought to take care of
-- formatting the forall prefix and hypotheses.  Something similar
-- should be used for declaring lc and degree.

-- XXX BEA: "brute_force" is hard-coded everywhere.

{- | Constructs the text for a lemma given its name, statement, and
   proof. -}

lemmaText' :: Name -> String -> String -> String
lemmaText' name stmt proof =
    printf "Lemma %s :\n\
           \  %s.\n\
           \Proof.\n\
           \%s\n\
           \Qed.\n\
           \\n"
           name stmt proof

{- | Constructs the text for a lemma given its name, statement, and
   proof.  Unlike 'lemmaText', the text generated here includes a
   @Hint Resolve@ declaration. -}

lemmaHintText :: Name -> String -> String -> String
lemmaHintText name stmt proof =
    printf "Lemma %s :\n\
           \  %s.\n\
           \Proof.\n\
           \%s\n\
           \Qed.\n\
           \\n\
           \Hint Resolve %s : brute_force.\n\
           \\n"
           name stmt proof name


{- ----------------------------------------------------------------------- -}
{- * Processing patterns -}

{- | Rough description: Captures the pattern where the portions of
   lemma need to be assembled together. -}

lemmaText :: Bool
          -- ^ Whether or not to generate a @Resolve@ hint.
          -> Bool
          -- ^ Whether or not to generate a @Rewrite@ hint.
          -> Name
          -- ^ The name of the lemma.
          -> String
          -- ^ The statement of the lemma.
          -> String
          -- ^ The proof script.
          -> String
lemmaText resolve rewrite name stmt proof =
    printf "Lemma %s :\n\
           \%s.\n\
           \Proof.\n\
           \%s\n\
           \Qed.\n\
           \\n\
           \%s%s"
           name stmt proof hint_resolve hint_rewrite
    where
      hint_resolve = if resolve
                     then printf "Hint Resolve %s : %s.\n\n" name hintDb
                     else ""

      hint_rewrite = if rewrite
                     then printf "Hint Rewrite %s : %s.\n\n" name hintDb
                     else ""

{- | Rough description: Captures the pattern where we need to do
   something for each (@nt1@, @nt2@) pair. -}

processByBindOver :: ASTAnalysis
                       -> Bool
                       -- ^ Whether or not to generate @Resolve@ hints.
                       -> Bool
                       -- ^ Whether or not to generate @Rewrite@ hints.
                       -> [String]
                       -- ^ Hint databases for hint declarations.
                       -> [NtRoot]
                       -- ^ Mutually inductive set of nonterminals (@nt1s@).
                       -> NtRoot
                       -- ^ Nonterminal that binds in the above (@nt2@).
                       -> (ASTAnalysis -> NtRoot -> NtRoot -> M String)
                       -- ^ Computes a name for each (@nt1@, @nt2@) pair.
                       -> (ASTAnalysis -> NtRoot -> NtRoot -> M (String, String))
                       -- ^ Computes the main theorem statement and proof for each (@nt1@, @nt2@) pair.
                       -> M String
processByBindOver aa resolve rewrite dbs nt1s nt2 name gen =
    do { names <- mapM (local . flip (name aa) nt2) nt1s
       ; gens  <- mapM (local . flip (gen aa) nt2) nt1s
       ; let res = do { (n, (stmt, pf), nt1) <- zip3 names gens nt1s
                      ; return $ printf
                        "Lemma %s :\n\
                        \%s.\n\
                        \Proof.\n\
                        \%s\n\
                        \Qed.\n\
                        \\n\
                        \%s%s"
                        n
                        stmt
                        pf
                        (hint_resolve nt1) (hint_rewrite nt1)
                      }
       ; return $ concat res
       }
    where
      hint_resolve nt1 =
          if resolve
          then runM $ do { n <- name aa nt1 nt2
                         ; return $ printf
                           "Hint Resolve %s : %s.\n\n"
                           n (sepStrings " " dbs)
                         }
          else ""

      hint_rewrite nt1 =
          if rewrite
          then runM $ do { n <- name aa nt1 nt2
                         ; return $ printf
                           "Hint Rewrite %s : %s.\n\n"
                           n (sepStrings " " dbs)
                         }
          else ""

{- | Rough description: Captures the pattern where we need to do
   something for each @nt2@ while treating the given collection of
   roots as a monolithic block. -}

processBlockByBindOver :: ASTAnalysis
                       -> Bool
                       -- ^ Whether or not to generate @Resolve@ hints.
                       -> Bool
                       -- ^ Whether or not to generate @Rewrite@ hints.
                       -> [String]
                       -- ^ Hint databases for hint declarations.
                       -> ([Name] -> Name)
                       -- ^ Generates the name of the mutual induction principle to use.
                       -> [NtRoot]
                       -- ^ Mutually inductive set of nonterminals (@nt1s@).
                       -> NtRoot
                       -- ^ Nonterminal that binds in the above (@nt2@).
                       -> (ASTAnalysis -> NtRoot -> NtRoot -> M String)
                       -- ^ Computes a name for each (@nt1@, @nt2@) pair.
                       -> (ASTAnalysis -> NtRoot -> NtRoot -> M String)
                       -- ^ Computes the main theorem statement for each (@nt1@, @nt2@) pair.
                       -> (ASTAnalysis -> NtRoot -> NtRoot -> M String)
                       -- ^ Computes the corollary statement for each (@nt1@, @nt2@) pair.
                       -> (ASTAnalysis -> [NtRoot] -> NtRoot -> M String)
                       -- ^ Computes the main proof, not including the initial induction step.
                       -> M String
processBlockByBindOver aa resolve rewrite dbs mutName nt1s nt2 name thm thm' pf =
    do { stms        <- mapM (local . flip (thm aa) nt2) nt1s
       ; proof       <- local getProof
       ; corollaries <- mapM (local . corollary) nt1s
       ; return $ printf
         "Lemma %s :\n\
         \%s.\n\
         \Proof.\n\
         \%s\n\
         \Qed.\n\
         \\n\
         \%s"
         big_name
         (sepStrings "\n/\\\n" (map wrap stms))
         (proof :: String)
         (concat corollaries :: String)
       }
    where
      wrap s = "(" ++ s ++ ")"

      big_name = runM $ do { ns <- mapM (flip (name aa) nt2) nt1s
                           ; return $ sepStrings "_" ns ++ "_mutind"
                           }

      types = runM $ mapM (ntType aa) nt1s

      getProof =
          do { proof <- pf aa nt1s nt2
             ; h     <- newName "H"
             ; return $ printf
               "first [ intros %s; pattern %s; apply %s\n\
               \      | apply %s ];\n\
               \%s"
               h h (mutName types)
               (mutName types)
               proof
             }

      hint_resolve nt1 =
          if resolve
          then runM $ do { n <- name aa nt1 nt2
                         ; return $ printf
                           "Hint Resolve %s : %s.\n\n"
                           n (sepStrings " " dbs)
                         }
          else ""

      hint_rewrite nt1 =
          if rewrite
          then runM $ do { n <- name aa nt1 nt2
                         ; return $ printf
                           "Hint Rewrite %s : %s.\n\n"
                           n (sepStrings " " dbs)
                         }
          else ""

      corollary nt1 =
          do { n    <- name aa nt1 nt2
             ; stmt <- thm' aa nt1 nt2
             ; return $ printf
               "Lemma %s :\n\
               \%s.\n\
               \Proof. pose proof %s; intuition. Qed.\n\
               \\n\
               \%s%s"
               n
               stmt
               big_name
               (hint_resolve nt1)
               (hint_rewrite nt1)
             }

{- | Rough description: Captures the pattern where we need to do
   something for each (@nt1@, @mv@) pair. -}

processMv :: ASTAnalysis
          -> Bool
          -- ^ Whether or not to generate @Resolve@ hints.
          -> Bool
          -- ^ Whether or not to generate @Rewrite@ hints.
          -> [String]
          -- ^ Hint databases for hint declarations.
          -> [NtRoot]
          -- ^ Mutually inductive set of nonterminals (@nt1s@).
          -> MvRoot
          -> (ASTAnalysis -> NtRoot -> MvRoot -> M String)
          -- ^ Computes a name for each (@nt1@, @mv@) pair.
          -> (ASTAnalysis -> NtRoot -> MvRoot -> M (String, String))
          -- ^ Computes the main theorem statement and proof for each (@nt1@, @mv@) pair.
          -> M String
processMv = processByBindOver

{- | Rough description: Captures the pattern where we need to do
   something for each @mv@ while treating the given collection of
   roots as a monolithic block. -}

processBlockMv :: ASTAnalysis
               -> Bool
               -- ^ Whether or not to generate @Resolve@ hints.
               -> Bool
               -- ^ Whether or not to generate @Rewrite@ hints.
               -> [String]
               -- ^ Hint databases for hint declarations.
               -> ([Name] -> Name)
               -- ^ Generates the name of the mutual induction principle to use.
               -> [NtRoot]
               -- ^ Mutually inductive set of nonterminals (@nt1s@).
               -> MvRoot
               -> (ASTAnalysis -> NtRoot -> MvRoot -> M String)
               -- ^ Computes a name for each (@nt1@, @mv@) pair.
               -> (ASTAnalysis -> NtRoot -> NtRoot -> M String)
               -- ^ Computes the main theorem statement for each (@nt1@, @mv@) pair.
               -> (ASTAnalysis -> NtRoot -> NtRoot -> M String)
               -- ^ Computes the corollary statement for each (@nt1@, @mv@) pair.
               -> (ASTAnalysis -> [NtRoot] -> NtRoot -> M String)
               -- ^ Computes the main proof, not including the initial induction step.
               -> M String
processBlockMv = processBlockByBindOver


{- ----------------------------------------------------------------------- -}
{- * Theorems about local closure -}

processLcThms :: ASTAnalysis -> [NtRoot] -> M String
processLcThms aa nts' =
    do { let nts = filter (isOpenable aa) nts'
       ; block1 <- mapM (local . lcExists aa) nts
       ; return $ concat block1
       }

lcExists :: ASTAnalysis -> NtRoot -> M String
lcExists aa nt1 =
    do { (Syntax _ _ cs) <- getSyntax aa nt1
       ; thms            <- mapM (local . lcExistsConstr) cs
       ; return $ concat thms
       }
    where
      lcExistsConstr c@(SConstr _ _ _ ts _)
          | hasBindingArg ts =
              do { n    <- lcExConstrName aa c nt1
                 ; x    <- newName "x"
                 ; stmt <- thm c x
                 ; lc   <- lcName aa nt1
                 ; let proof = printf "default_simp; apply %s; eauto with brute_force."
                                      (lc ++ "_of_degree")
                 ; return $ lemmaHintText n stmt proof
                 }
          | otherwise =
              return ""

      -- XXX WARNING BEA: This statement assumes that there is only
      -- implementation type for metavariables.

      thm c@(SConstr _ _ _ ts _) x =
          do { lc   <- lcName aa nt1
             ; args <- mapM (newName . toRoot) ts
             ; hyps <- mapM (getHyp x) (zip ts args)
             ; return $ printf
                 "%s\n\
                 \       %s\
                 \%s (%s%s)"
                 (forallPrefix (x : args))
                 (sepStrings "\n    -> " (filter (/= "") hyps ++ [""]))
                 lc (toName c) (sepStrings " " ("" : args))
             }

      forallPrefix [] = ""
      forallPrefix xs = "forall " ++ (sepStrings " " xs) ++ ","

      getHyp _ (MvArg _,  _) = return ""
      getHyp _ (IndexArg, _) = return ""

      getHyp _ (NtArg ntr, arg)
          | isOpenable aa ntr =
              do { lc <- lcName aa ntr
                 ; return $ printf "%s %s" lc arg
                 }
          | otherwise =
              return ""

      getHyp x (BindingArg _ nt nt2, arg) =
          do { lc      <- lcName aa nt2
             ; open_fn <- openName aa nt2 nt
             ; constr  <- getFreeVarConstr aa nt
             ; return $ printf "%s (%s %s (%s %s))"
                               lc open_fn arg (toName constr) x
             }


{- ----------------------------------------------------------------------- -}
{- * Theorems about @subst@ -}

processSubstThms :: ASTAnalysis -> [NtRoot] -> M String
processSubstThms aa nts =
    do { let nt2s = filter (canBindOver aa (head nts)) (ntRoots aa)
       ; freshEq   <- mapM (local . substFreshEq aa nts) nt2s
       ; freshSame <- mapM (local . substFreshSame aa nts) nt2s
       ; fresh     <- mapM (local . substFresh aa nts) nt2s
       ; lc        <- mapM (local . substLc aa nts) nt2s
       ; return $ concat freshEq ++
                  concat freshSame ++
                  concat fresh ++
                  concat lc
       }

substFreshSame :: ASTAnalysis -> [NtRoot] -> NtRoot -> M String
substFreshSame aa nts nt2 =
    if length nts == 1 then
        do { let nt1 = head nts
           ; n    <- name nt1
           ; mv   <- mvOfNt aa nt2
           ; x    <- newName mv
           ; e    <- newName nt1
           ; u    <- newName nt2
           ; stmt <- thm nt1 x u e
           ; let proof = "induction " ++ e ++ "; default_simp." {- XXX -}
           ; return $ lemmaHintText n stmt proof
           }
    else
        do { names <- mapM name nts
           ; types <- mapM (ntType aa) nts
           ; mv    <- mvOfNt aa nt2
           ; x     <- newName mv
           ; u     <- newName nt2
           ; es    <- mapM newName nts
           ; conjs <- mapM (\(n,e) -> thm n x u e)  (zip nts es)
           ; let cname = sepStrings "_" names
           ; let stmt  = sepStrings " /\\\n  " $ map wrap conjs
           ; let tac   = mutIndName types
           ; let pf    = "apply " ++ tac ++ "; default_simp."
           ; let clem  = lemmaText' cname stmt pf
           ; let pf'   = "pose proof " ++ cname ++ "; intuition."
           ; let lems  = map (\(n,s1,s2) -> lemmaHintText n s1 s2)
                             (zip3 names conjs (repeat pf'))
           ; return $ clem ++ concat lems
           }
    where
      name nt1 =
          do { fn <- substName aa nt1 nt2
             ; return $ fn ++ "_fresh_same"
             }

      wrap s = "(" ++ s ++ ")"

      thm nt1 x u e =
          do { subst_fn <- substName aa nt1 nt2
             ; fv_fn    <- fvName aa nt1 nt2
             ; fv_fn'   <- fvName aa nt2 nt2
             ; return $ printf "forall %s %s %s,\n\
                               \       %s %s %s %s\n\
                               \    -> %s %s %s (%s %s %s %s)"
                        e x u
                        x mvSetNotin fv_fn' u
                        x mvSetNotin fv_fn subst_fn x u e
             }

substFresh :: ASTAnalysis -> [NtRoot] -> NtRoot -> M String
substFresh aa nts nt2 =
    if length nts == 1 then
        do { let nt1 = head nts
           ; n    <- name nt1
           ; mv   <- mvOfNt aa nt2
           ; x    <- newName mv
           ; y    <- newName mv
           ; e    <- newName nt1
           ; u    <- newName nt2
           ; stmt <- thm nt1 x y u e
           ; let proof = "induction " ++ e ++ "; default_simp." {- XXX -}
           ; return $ lemmaHintText n stmt proof
           }
    else
        do { names <- mapM name nts
           ; types <- mapM (ntType aa) nts
           ; mv    <- mvOfNt aa nt2
           ; x     <- newName mv
           ; y     <- newName mv
           ; u     <- newName nt2
           ; es    <- mapM newName nts
           ; conjs <- mapM (\(n,e) -> thm n x y u e)  (zip nts es)
           ; let cname = sepStrings "_" names
           ; let stmt  = sepStrings " /\\\n  " $ map wrap conjs
           ; let tac   = mutIndName types
           ; let pf    = "apply " ++ tac ++ "; default_simp."
           ; let clem  = lemmaText' cname stmt pf
           ; let pf'   = "pose proof " ++ cname ++ "; intuition."
           ; let lems  = map (\(n,s1,s2) -> lemmaHintText n s1 s2)
                             (zip3 names conjs (repeat pf'))
           ; return $ clem ++ concat lems
           }
    where
      name nt1 =
          do { fn <- substName aa nt1 nt2
             ; return $ fn ++ "_fresh"
             }

      wrap s = "(" ++ s ++ ")"

      thm nt1 x y u e =
          do { subst_fn <- substName aa nt1 nt2
             ; fv_fn    <- fvName aa nt1 nt2
             ; fv_fn'   <- fvName aa nt2 nt2
             ; return $ printf "forall %s %s %s %s,\n\
                               \       %s %s %s %s\n\
                               \    -> %s %s %s %s\n\
                               \    -> %s %s %s (%s %s %s %s)"
                        e x y u
                        x mvSetNotin fv_fn e
                        x mvSetNotin fv_fn' u
                        x mvSetNotin fv_fn subst_fn y u e
             }


{- ----------------------------------------------------------------------- -}
{- * Theorems about @subst@ and @open@ -}

processSubstOpenThms :: ASTAnalysis -> [NtRoot] -> M String
processSubstOpenThms aa nts =
    do { let nt2s = filter (canBindOver aa (head nts)) (ntRoots aa)
       ; openRec  <- sequence $ map local $ substOpenRec aa nts
       ; open     <- sequence $ map local $ substOpen aa nts
       ; openVar  <- sequence $ map local $ substOpenVar aa nts
       ; introRec <- mapM (local . substIntroRec aa nts) nt2s
       ; intro    <- mapM (local . substIntro aa nts) nt2s
       ; return $ concat openRec ++
                  concat open ++
                  concat openVar ++
                  concat introRec ++
                  concat intro
       }

substOpenRec :: ASTAnalysis -> [NtRoot] -> [M String]
substOpenRec aa nts
    | length nts == 0 =
        return $ return ""
    | length nts == 1 =
        do { let nt1 = head nts
           ; nt2  <- filter (canBindOver aa nt1) (ntRoots aa)
           ; nt2' <- filter (canBindOver aa nt1) (ntRoots aa)
           ; return $ do
               { n    <- name nt1 nt2 nt2'
               ; mv   <- mvOfNt aa nt2
               ; x    <- newName mv
               ; k    <- newName bvarRoot
               ; e    <- newName nt1
               ; u    <- newName nt2
               ; u'   <- newName nt2'
               ; stmt <- thm nt1 nt2 nt2' e x u k u'
               ; let proof = "induction " ++ e ++ "; default_simp." {- XXX -}
               ; return $ lemmaHintText n stmt proof
               }
           }
    | otherwise =
        do { let nt1 = head nts
           ; nt2  <- filter (canBindOver aa nt1) (ntRoots aa)
           ; nt2' <- filter (canBindOver aa nt1) (ntRoots aa)
           ; return $ do
               { names <- mapM (\n -> name n nt2 nt2') nts
               ; types <- mapM (ntType aa) nts
               ; mv    <- mvOfNt aa nt2
               ; x     <- newName mv
               ; k     <- newName bvarRoot
               ; u     <- newName nt2
               ; u'    <- newName nt2'
               ; es    <- mapM newName nts
               ; conjs <- mapM (\(n,e) -> thm n nt2 nt2' e x u k u') (zip nts es)
               ; let cname = sepStrings "_" names
               ; let stmt  = sepStrings " /\\\n  " $ map wrap conjs
               ; let tac   = mutIndName types
               ; let pf    = "apply " ++ tac ++ "; default_simp."
               ; let clem  = lemmaText' cname stmt pf
               ; let pf'   = "apply " ++ cname ++ "."
               ; let lems  = map (\(n,s1,s2) -> lemmaHintText n s1 s2)
                                 (zip3 names conjs (repeat pf'))
               ; return $ clem ++ concat lems
               }
           }
    where
      name nt1 nt2 nt2' =
          do { subst <- substName aa nt1 nt2
             ; open  <- openRecName aa nt1 nt2'
             ; return $ subst ++ "_" ++ open
             }

      wrap s = "(" ++ s ++ ")"

      thm nt1 nt2 nt2' e x u k u'
          | canBindOver aa nt2' nt2 =
              do { subst_fn  <- substName aa nt1 nt2
                 ; subst_fn2 <- substName aa nt2' nt2
                 ; open_fn   <- openRecName aa nt1 nt2'
                 ; lc        <- lcName aa nt2
                 ; return $ printf "forall %s %s %s %s %s,\n\
                                   \       %s\
                                   \%s %s %s (%s %s %s %s) =\n\
                                   \          %s %s (%s %s %s %s) (%s %s %s %s)"
                                   e u u' x k
                                   (lcH nt2 nt2' lc u)
                                   subst_fn x u open_fn k u' e
                                   open_fn k subst_fn2 x u u' subst_fn x u e
                 }
          | otherwise =
              do { subst_fn  <- substName aa nt1 nt2
                 ; open_fn   <- openRecName aa nt1 nt2'
                 ; lc        <- lcName aa nt2
                 ; return $ printf "forall %s %s %s %s %s,\n\
                                   \       %s\
                                   \%s %s %s (%s %s %s %s) =\n\
                                   \          %s %s %s (%s %s %s %s)"
                                   e u u' x k
                                   (lcH nt2 nt2' lc u)
                                   subst_fn x u open_fn k u' e
                                   open_fn k u' subst_fn x u e
                 }

      lcH nt2 nt2' lc u
          | canBindIn aa nt2' nt2 = lc ++ " " ++ u ++ "\n    -> "
          | otherwise                = ""

substOpen :: ASTAnalysis -> [NtRoot] -> [M String]
substOpen aa nts =
    do { nt1 <- nts
       ; nt2  <- filter (canBindOver aa nt1) (ntRoots aa)
       ; nt2' <- filter (canBindOver aa nt1) (ntRoots aa)
       ; return $ lem nt1 nt2 nt2'
       }
    where
      name nt1 nt2 nt2' =
          do { subst <- substName aa nt1 nt2
             ; open  <- openName aa nt1 nt2'
             ; return $ subst ++ "_" ++ open
             }

      lem nt1 nt2 nt2' =
          do { n          <- name nt1 nt2 nt2'
             ; mv         <- mvOfNt aa nt2
             ; x          <- newName mv
             ; e          <- newName nt1
             ; u          <- newName nt2
             ; u'         <- newName nt2'
             ; open_fn    <- openName aa nt1 nt2'
             ; stmt       <- thm nt1 nt2 nt2' e x u u'
             ; let proof = printf "unfold %s; default_simp." open_fn
             ; return $ lemmaHintText n stmt proof
             }


      thm nt1 nt2 nt2' e x u u'
          | canBindOver aa nt2' nt2 =
              do { subst_fn  <- substName aa nt1 nt2
                 ; subst_fn2 <- substName aa nt2' nt2
                 ; open_fn   <- openName aa nt1 nt2'
                 ; lc        <- lcName aa nt2
                 ; return $ printf "forall %s %s %s %s,\n\
                                   \       %s\
                                   \%s %s %s (%s %s %s) =\n\
                                   \          %s (%s %s %s %s) (%s %s %s %s)"
                                   e u u' x
                                   (lcH nt2 nt2' lc u)
                                   subst_fn x u open_fn e u'
                                   open_fn subst_fn x u e subst_fn2 x u u'
                 }
          | otherwise =
              do { subst_fn  <- substName aa nt1 nt2
                 ; open_fn   <- openName aa nt1 nt2'
                 ; lc        <- lcName aa nt2
                 ; return $ printf "forall %s %s %s %s,\n\
                                   \       %s\
                                   \%s %s %s (%s %s %s) =\n\
                                   \          %s (%s %s %s %s) %s"
                                   e u u' x
                                   (lcH nt2 nt2' lc u)
                                   subst_fn x u open_fn e u'
                                   open_fn subst_fn x u e u'
                 }

      lcH nt2 nt2' lc u
          | canBindIn aa nt2' nt2 = lc ++ " " ++ u ++ "\n    -> "
          | otherwise                = ""

substOpenVar :: ASTAnalysis -> [NtRoot] -> [M String]
substOpenVar aa nts =
    do { nt1 <- nts
       ; nt2  <- filter (canBindOver aa nt1) (ntRoots aa)
       ; nt2' <- filter (canBindOver aa nt1) (ntRoots aa)
       ; return $ lem nt1 nt2 nt2'
       }
    where
      name nt1 nt2 nt2' =
          do { subst <- substName aa nt1 nt2
             ; open  <- openName aa nt1 nt2'
             ; return $ subst ++ "_" ++ open ++ "_var"
             }

      lem nt1 nt2 nt2' =
          do { n        <- name nt1 nt2 nt2'
             ; mv       <- mvOfNt aa nt2
             ; x        <- newName mv
             ; e        <- newName nt1
             ; u        <- newName nt2
             ; mv'      <- mvOfNt aa nt2'
             ; y        <- newName mv'
             ; subst_fn <- substName aa nt1 nt2
             ; open_fn  <- openName aa nt1 nt2'
             ; stmt     <- thm nt1 nt2 nt2' e x u y
             ; let proof = printf "intros; rewrite %s; default_simp."
                                  (subst_fn ++ "_" ++ open_fn)
             ; return $ lemmaHintText n stmt proof
             }

      thm nt1 nt2 nt2' e x u y =
          do { subst_fn <- substName aa nt1 nt2
             ; open_fn  <- openName aa nt1 nt2'
             ; lc       <- lcName aa nt2
             ; constr   <- getFreeVarConstr aa nt2'
             ; let hyps = neqH nt2 nt2' x y : lcH nt2 nt2' lc u : []
             ; return $ printf "forall %s %s %s %s,\n\
                               \       %s\
                               \%s (%s %s %s %s) (%s %s) =\n\
                               \          %s %s %s (%s %s (%s %s))"
                        e u x y
                        (sepStrings "\n    -> " (filter (/= "") hyps ++ [""]))
                        open_fn subst_fn x u e (toName constr) y
                        subst_fn x u open_fn e (toName constr) y
             }

      neqH nt2 nt2' x y
          | canonRoot aa nt2 == canonRoot aa nt2' = x ++ " <> " ++ y
          | otherwise                             = ""

      lcH nt2 nt2' lc u
          | canBindIn aa nt2' nt2 = lc ++ " " ++ u
          | otherwise                = ""

substIntroRec :: ASTAnalysis -> [NtRoot] -> NtRoot -> M String
substIntroRec aa nts nt2 =
    if length nts == 1 then
        do { let nt1 = head nts
           ; n    <- name nt1
           ; mv   <- mvOfNt aa nt2
           ; x    <- newName mv
           ; k    <- newName bvarRoot
           ; e    <- newName nt1
           ; u    <- newName nt2
           ; stmt <- thm nt1 e u x k
           ; let proof = "induction " ++ e ++ "; default_simp." {- XXX -}
           ; return $ lemmaHintText n stmt proof
           }
    else
        do { names <- mapM name nts
           ; types <- mapM (ntType aa) nts
           ; mv    <- mvOfNt aa nt2
           ; x     <- newName mv
           ; k     <- newName bvarRoot
           ; u     <- newName nt2
           ; es    <- mapM newName nts
           ; conjs <- mapM (\(n,e) -> thm n e u x k) (zip nts es)
           ; let cname = sepStrings "_" names
           ; let stmt  = sepStrings " /\\\n  " $ map wrap conjs
           ; let tac   = mutIndName types
           ; let pf    = "apply " ++ tac ++ "; default_simp."
           ; let clem  = lemmaText' cname stmt pf
           ; let pf'   = "apply " ++ cname ++ "."
           ; let lems  = map (\(n,s1,s2) -> lemmaHintText n s1 s2)
                             (zip3 names conjs (repeat pf'))
           ; return $ clem ++ concat lems
           }
    where
      name nt1 =
          do { subst <- substName aa nt1 nt2
             ; return $ subst ++ "_intro_rec"
             }

      wrap s = "(" ++ s ++ ")"

      thm nt1 e u x k =
          do { subst_fn <- substName aa nt1 nt2
             ; open_fn  <- openRecName aa nt1 nt2
             ; fv_fn    <- fvName aa nt1 nt2
             ; constr   <- getFreeVarConstr aa nt2
             ; return $ printf "forall %s %s %s %s,\n\
                               \       %s %s %s %s\n\
                               \    -> %s %s %s %s =\n\
                               \          %s %s %s (%s %s (%s %s) %s)"
                        e u x k
                        x mvSetNotin fv_fn e
                        open_fn k u e
                        subst_fn x u open_fn k (toName constr) x e
             }

substIntro :: ASTAnalysis -> [NtRoot] -> NtRoot -> M String
substIntro aa nts nt2 =
    do { lems <- mapM lem nts
       ; return $ concat lems
       }
    where
      name nt1 =
          do { subst <- substName aa nt1 nt2
             ; return $ subst ++ "_intro"
             }

      lem nt1 =
          do { n    <- name nt1
             ; mv   <- mvOfNt aa nt2
             ; x    <- newName mv
             ; e    <- newName nt1
             ; u    <- newName nt2
             ; stmt <- thm nt1 e u x
             ; open <- openName aa nt1 nt2
             ; let proof = printf "unfold %s; default_simp." open
             ; return $ lemmaHintText n stmt proof
             }

      thm nt1 e u x =
          do { subst_fn <- substName aa nt1 nt2
             ; open_fn  <- openName aa nt1 nt2
             ; fv_fn    <- fvName aa nt1 nt2
             ; constr   <- getFreeVarConstr aa nt2
             ; return $ printf "forall %s %s %s,\n\
                               \       %s %s %s %s\n\
                               \    -> %s %s %s =\n\
                               \          %s %s %s (%s %s (%s %s))"
                        x e u
                        x mvSetNotin fv_fn e
                        open_fn e u
                        subst_fn x u open_fn e (toName constr) x
             }


{- ----------------------------------------------------------------------- -}
{- * Swapping -}

{- | Generates text for the @swap@ functions. -}

processSwap :: ASTAnalysis -> [NtRoot] -> M String
processSwap aa nts =
    do { swaps <- mapM (processSwapMv aa nts) (mvRoots aa)
       ; return $ concat swaps
       }

{- | Generates text for the @swap@ functions with respect to a
   particular metavariable. -}

processSwapMv :: ASTAnalysis -> [NtRoot] -> MvRoot -> M String
processSwapMv aa nts mv =
    do { defs <- mapM (local . def) nts
       ; return $ printf "Fixpoint %s.\n\n" (sepStrings "\n\nwith " defs)
       }
    where
      def nt =
          do { swap_fn         <- swapImplName aa nt mv
             ; ab              <- newName "ab"
             ; abType          <- mvType aa mv
             ; e               <- newName nt
             ; etype           <- ntType aa nt
             ; (Syntax _ _ cs) <- getSyntax aa nt
             ; branches        <- mapM (local . branch ab) cs
             ; return $ printf
               "%s (%s : %s * %s) (%s : %s) {struct %s} : %s :=\n\
               \  match %s with\n\
               \%s\n\
               \  end"
               swap_fn ab abType abType e etype e etype
               e
               (sepStrings "\n" branches)
             }

      branch ab c@(SConstr _ _ _ ts _) =
          do { args  <- mapM (newName . toRoot) ts
             ; calls <- mapM (call ab) (zip ts args)
             ; return $ printf "    | %s%s => %s%s"
                      (toName c)
                      (sepStrings " " ("" : args))
                      (toName c)
                      (sepStrings " " ("" : calls))
             }

      call _  (IndexArg,          z) = return z
      call ab (BindingArg _ _ nt, z) = call ab (NtArg nt, z)

      call ab (MvArg mv', z)
          | canonRoot aa mv == canonRoot aa mv' =
              return $ printf "(%s %s %s)" swapAtomName ab z
          | otherwise =
              return z

      call ab (NtArg nt, z) =
          do { fn <- swapImplName aa nt mv
             ; return $ printf "(%s %s %s)" fn ab z
             }


{- ----------------------------------------------------------------------- -}
{- * @Swap@ instances -}

{- | Generates the @Instance@ declarations for the @Swap@ class. -}

processSwapInstThms :: ASTAnalysis -> [NtRoot] -> M String
processSwapInstThms aa nts =
    do { block1 <- mapM (swapSameThm aa nts) (mvRoots aa)
       ; block2 <- mapM (swapInvolThm aa nts) (mvRoots aa)
       ; block3 <- mapM (swapDistribThm aa nts) (mvRoots aa)
       ; block4 <- mapM (swapInstances aa nts) (mvRoots aa)
       ; return $ "Strategy opaque [ " ++ swapAtomName ++ " ].\n\n" ++
                  concat block1 ++
                  concat block2 ++
                  concat block3 ++
                  concat block4 ++
                  "Strategy transparent [ " ++ swapAtomName ++ " ].\n\n"
       }

{- | Theorem: @swap (a, a) e = e@. -}

swapSameThm :: ASTAnalysis -> [NtRoot] -> MvRoot -> M String
swapSameThm aaa nt1s' mv' =
    processBlockMv aaa True False [hintDb, swapHintDb] mutIndName nt1s' mv' name thm thm' pf
    where
      name aa nt1 mv =
          do { swap <- swapImplName aa nt1 mv
             ; return $ swap ++ "_same"
             }

      thm aa nt1 mv =
          do { a    <- newName "a"
             ; e    <- newName nt1
             ; swap <- swapImplName aa nt1 mv
             ; return $ printf
               "forall %s %s,\n\
               \  %s (%s, %s) %s = %s"
               e a
               swap a a e e
             }

      thm' aa nt1 mv =
          do { a    <- newName "a"
             ; e    <- newName nt1
             ; swap <- swapImplName aa nt1 mv
             ; return $ printf
               "forall %s %s,\n\
               \  %s (%s, %s) %s = %s"
               a e
               swap a a e e
             }

      pf _ _ _ = return $ printf "%s; auto with %s." defaultSimp swapHintDb

{- | Theorem: @swap ab (swap ab e) = e@. -}

swapInvolThm :: ASTAnalysis -> [NtRoot] -> MvRoot -> M String
swapInvolThm aaa nt1s' mv' =
    processBlockMv aaa True False [hintDb, swapHintDb] mutIndName nt1s' mv' name thm thm' pf
    where
      name aa nt1 mv =
          do { swap <- swapImplName aa nt1 mv
             ; return $ swap ++ "_invol"
             }

      thm aa nt1 mv =
          do { ab   <- newName "ab"
             ; e    <- newName nt1
             ; swap <- swapImplName aa nt1 mv
             ; return $ printf
               "forall %s %s,\n\
               \  %s %s (%s %s %s) = %s"
               e ab
               swap ab swap ab e e
             }

      thm' aa nt1 mv =
          do { ab   <- newName "ab"
             ; e    <- newName nt1
             ; swap <- swapImplName aa nt1 mv
             ; return $ printf
               "forall %s %s,\n\
               \  %s %s (%s %s %s) = %s"
               ab e
               swap ab swap ab e e
             }

      pf _ _ _ = return $ printf "%s; auto with %s." defaultSimp swapHintDb

{- | Theorem: @swap ab (swap (c, d)  e) = ...@. -}

swapDistribThm :: ASTAnalysis -> [NtRoot] -> MvRoot -> M String
swapDistribThm aaa nt1s' mv' =
    processBlockMv aaa True False [hintDb, swapHintDb] mutIndName nt1s' mv' name thm thm' pf
    where
      name aa nt1 mv =
          do { swap <- swapImplName aa nt1 mv
             ; return $ swap ++ "_distrib"
             }

      thm aa nt1 mv =
          do { ab   <- newName "ab"
             ; c    <- newName "c"
             ; d    <- newName "d"
             ; e    <- newName nt1
             ; swap <- swapImplName aa nt1 mv
             ; return $ printf
               "forall %s %s %s %s,\n\
               \  %s %s (%s (%s, %s) %s) =\n\
               \  %s (%s %s %s, %s %s %s) (%s %s %s)"
               e ab c d
               swap ab swap c d e
               swap swapAtomName ab c swapAtomName ab d swap ab e
             }

      thm' aa nt1 mv =
          do { ab   <- newName "ab"
             ; c    <- newName "c"
             ; d    <- newName "d"
             ; e    <- newName nt1
             ; swap <- swapImplName aa nt1 mv
             ; return $ printf
               "forall %s %s %s %s,\n\
               \  %s %s (%s (%s, %s) %s) =\n\
               \  %s (%s %s %s, %s %s %s) (%s %s %s)"
               ab c d e
               swap ab swap c d e
               swap swapAtomName ab c swapAtomName ab d swap ab e
             }

      pf _ _ _ = return $ printf "%s; auto with %s." defaultSimp swapDistribHintDb

{- | Theorem: @Swap@ instance declaration. -}

swapInstances :: ASTAnalysis -> [NtRoot] -> MvRoot -> M String
swapInstances aa nts mv =
    do { defs <- mapM (local . def) nts
       ; return $ concat defs
       }
    where
      def nt =
          do { n    <- newName nt
             ; m    <- newName mv
             ; a    <- mvType aa mv
             ; t    <- ntType aa nt
             ; swap <- swapImplName aa nt mv
             ; return $ printf
               "Instance %s_%s%s : %s %s %s _ := {\n\
               \  %s := %s;\n\
               \  %s := %s;\n\
               \  %s := %s;\n\
               \  %s := %s\n\
               \}.\n\
               \\n"
               swapClass n m swapClass a t
               swapName    swap
               swapSame    (swap ++ "_same")
               swapInvol   (swap ++ "_invol")
               swapDistrib (swap ++ "_distrib")
             }
