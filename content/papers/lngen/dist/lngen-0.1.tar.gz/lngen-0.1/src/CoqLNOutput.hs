{-# OPTIONS_GHC -fcontext-stack=50 #-}

{- | This module defines the functions necessary to transform an 'AST'
   into a 'String' containing output for the Coq proof assistant.
   Definitions are encoded using a locally nameless representation. -}

module CoqLNOutput ( coqOfAST ) where

import Control.Monad ( when )
import Data.Graph    ( SCC(..), stronglyConnComp )
import Data.Maybe    ( catMaybes )
import Text.Printf   ( printf )

import AST
import ASTAnalysis
import ComputationMonad
import CoqLNOutputCommon
import CoqLNOutputCombinators
import CoqLNOutputDefinitions
import MyLibrary ( nmap, sepStrings )


{- ----------------------------------------------------------------------- -}
{- * Exported functionality -}

{- | Generates Coq output for the given 'AST'. -}

coqOfAST :: [String] -- ^ Paths to use with @LoadPath@.
         -> AST
         -> M String
coqOfAST paths ast =
    do { closeStrs   <- mapM (local . processClose aa) nts
       ; degreeStrs  <- mapM (local . processDegree aa) nts
       ; fvStrs      <- mapM (local . processFv aa) nts
       ; lcStrs      <- mapM (local . processLc aa) nts
       ; mvdStrs     <- mapM (local . processMv aa) (mvRoots aa)
       ; ntStrs      <- mapM (local . processNt aa) nts
       ; openStrs    <- mapM (local . processOpen aa) nts
       ; phantomStrs <- mapM (local . processPhantom aa) (phantomRoots aa)
       ; sizeStrs    <- mapM (local . processSize aa) nts
       ; substStrs   <- mapM (local . processSubst aa) nts
       ; tacticStrs  <- local $ processTactics aa

       ; close_degree_recs  <- mapM (local . close_degree_rec aa) nts
       ; close_inj_recs     <- mapM (local . close_inj_rec aa) nts
       ; close_injs         <- mapM (local . close_inj aa) nts
       ; close_lcs          <- mapM (local . close_lc aa) nts
       ; close_open_recs    <- mapM (local . close_open_rec aa) nts
       ; close_opens        <- mapM (local . close_open aa) nts

       ; degree_Os             <- mapM (local . degree_O aa) nts
       ; degree_Ss             <- mapM (local . degree_S aa) nts
       ; degree_close_recs     <- mapM (local . degree_close_rec aa) nts
       ; degree_closes         <- mapM (local . degree_close aa) nts
       ; degree_close_inv_recs <- mapM (local . degree_close_inv_rec aa) nts
       ; degree_close_invs     <- mapM (local . degree_close_inv aa) nts

       ; degree_of_lcs         <- mapM (local . degree_of_lc aa) nts

       ; degree_open_recs      <- mapM (local . degree_open_rec aa) nts
       ; degree_opens          <- mapM (local . degree_open aa) nts
       ; degree_open_inv_recs  <- mapM (local . degree_open_inv_rec aa) nts
       ; degree_open_invs      <- mapM (local . degree_open_inv aa) nts

       ; fv_close_recs      <- mapM (local . fv_close_rec aa) nts
       ; fv_closes          <- mapM (local . fv_close aa) nts
       ; fv_open_rec_lowers <- mapM (local . fv_open_rec_lower aa) nts
       ; fv_open_lowers     <- mapM (local . fv_open_lower aa) nts
       ; fv_open_rec_uppers <- mapM (local . fv_open_rec_upper aa) nts
       ; fv_open_uppers     <- mapM (local . fv_open_upper aa) nts
       ; fv_subst_freshs    <- mapM (local . fv_subst_fresh aa) nts
       ; fv_subst_lowers    <- mapM (local . fv_subst_lower aa) nts
       ; fv_subst_notins    <- mapM (local . fv_subst_notin aa) nts
       ; fv_subst_uppers    <- mapM (local . fv_subst_upper aa) nts

       ; lc_of_degrees      <- mapM (local . lc_of_degree aa) nts
       ; lc_existss         <- mapM (local . lc_exists aa) nts
       ; lc_uniques         <- mapM (local . lc_unique aa) nts

       ; open_close_recs    <- mapM (local . open_close_rec aa) nts
       ; open_closes        <- mapM (local . open_close aa) nts
       ; open_degree_recs   <- mapM (local . open_degree_rec aa) nts
       ; open_inj_recs      <- mapM (local . open_inj_rec aa) nts
       ; open_injs          <- mapM (local . open_inj aa) nts
       ; open_lcs           <- mapM (local . open_lc aa) nts

       ; size_mins          <- mapM (local . size_min aa) nts
       ; size_close_recs    <- mapM (local . size_close_rec aa) nts
       ; size_closes        <- mapM (local . size_close aa) nts
       ; size_open_recs     <- mapM (local . size_open_rec aa) nts
       ; size_opens         <- mapM (local . size_open aa) nts
       ; size_open_rec_vars <- mapM (local . size_open_rec_var aa) nts
       ; size_open_vars     <- mapM (local . size_open_var aa) nts

       ; subst_close_recs      <- mapM (local . subst_close_rec aa) nts
       ; subst_closes          <- mapM (local . subst_close aa) nts
       ; subst_close_open_recs <- mapM (local . subst_close_open_rec aa) nts
       ; subst_close_opens     <- mapM (local . subst_close_open aa) nts
       ; subst_constrs         <- mapM (local . subst_constr aa) nts
       ; subst_degrees         <- mapM (local . subst_degree aa) nts
       ; subst_freshs          <- mapM (local . subst_fresh aa) nts
       ; subst_lcs             <- mapM (local . subst_lc aa) nts
       ; subst_open_recs       <- mapM (local . subst_open_rec aa) nts
       ; subst_opens           <- mapM (local . subst_open aa) nts
       ; subst_open_vars       <- mapM (local . subst_open_var aa) nts
       ; subst_spec_recs       <- mapM (local . subst_spec_rec aa) nts
       ; subst_specs           <- mapM (local . subst_spec aa) nts
       ; subst_substs          <- mapM (local . subst_subst aa) nts

       ; return $ concatMap (printf "Add LoadPath \"%s\".\n") paths ++
                  coqHeader ++ "\n" ++
                  (if not (null (phantomStrs))
                   then coqSep ++ "(** * Ott \"Phantom\" declarations *)\n\n" ++
                        concat phantomStrs ++ "\n"
                   else "")
                  ++
                  coqSep ++ "(** * Metavariable declarations *)\n\
                            \\n\
                            \(** The rest of this file assumes that [EqDec] and [Atom] instances\n\
                            \    are already declared for the implementation types below. *)\n\
                            \\n" ++
                  concat mvdStrs ++ "\n" ++
                  coqSep ++ "(** * Nonterminal declarations *)\n\n" ++
                  concat ntStrs ++ "\n" ++
                  coqSep ++ "(** * Close *)\n\n" ++
                  concat closeStrs ++ "\n" ++
                  coqSep ++ "(** * Free variables *)\n\n" ++
                  concat fvStrs ++ "\n" ++
                  coqSep ++ "(** * Open *)\n\
                            \\n\
                            \(** The definitions below are only correct under the following\n\
                            \    condition: when substituting for index [n], the [degree] of\n\
                            \    the term being substituted in should also be [n]. *)\n\
                            \\n" ++
                  concat openStrs ++ "\n" ++
                  coqSep ++ "(** * Size *)\n\n" ++
                  concat sizeStrs ++ "\n" ++
                  coqSep ++ "(** * Substitution *)\n\n" ++
                  concat substStrs ++ "\n" ++
                  coqSep ++ "(** * Degree *)\n\
                            \\n\
                            \(** These define only an upper bound, not a strict upper bound. *)\n\
                            \\n" ++
                  concat degreeStrs ++ "\n" ++
                  coqSep ++ "(** * Local closure *)\n\n" ++
                  concat lcStrs ++ "\n" ++
                  coqSep ++ "(** * Tactic support *)\n\n" ++
                  tacticStrs ++ "\n" ++
                  coqSep ++ "(** * Theorems about [size] *)\n\n" ++
                  concat size_mins ++
                  concat size_close_recs ++
                  concat size_closes ++
                  concat size_open_recs ++
                  concat size_opens ++
                  concat size_open_rec_vars ++
                  concat size_open_vars ++ "\n" ++
                  coqSep ++ "(** * Theorems about [degree] *)\n\n" ++
                  concat degree_Ss ++
                  concat degree_Os ++
                  concat degree_close_recs ++
                  concat degree_closes ++
                  concat degree_close_inv_recs ++
                  concat degree_close_invs ++
                  concat degree_open_recs ++
                  concat degree_opens ++
                  concat degree_open_inv_recs ++
                  concat degree_open_invs ++ "\n" ++
                  coqSep ++ "(** * Theorems about [open] and [close] *)\n\n" ++
                  concat close_inj_recs ++
                  concat close_injs ++
                  concat close_open_recs ++
                  concat close_opens ++
                  concat open_close_recs ++
                  concat open_closes ++
                  concat open_inj_recs ++
                  concat open_injs ++ "\n" ++
                  coqSep ++ "(** * Theorems about [lc] *)\n\n" ++
                  concat degree_of_lcs ++
                  concat lc_of_degrees ++
                  (concat $ concat lc_existss) ++
                  concat lc_uniques ++ "\n" ++
                  coqSep ++ "(** * More theorems about [open] and [close] *)\n\n" ++
                  concat close_degree_recs ++
                  concat close_lcs ++
                  concat open_degree_recs ++
                  concat open_lcs ++ "\n" ++
                  coqSep ++ "(** * Theorems about [subst] *)\n\n" ++
                  concat subst_close_recs ++
                  concat subst_closes ++
                  concat subst_degrees ++
                  concat subst_freshs ++
                  concat subst_lcs ++
                  concat subst_open_recs ++
                  concat subst_opens ++
                  concat subst_open_vars ++
                  concat subst_spec_recs ++
                  concat subst_specs ++
                  concat subst_substs ++ "\n" ++
                  coqSep ++ "(** * Theorems about [fv] *)\n\n" ++
                  concat fv_close_recs ++
                  concat fv_closes ++
                  concat fv_open_rec_lowers ++
                  concat fv_open_lowers ++
                  concat fv_open_rec_uppers ++
                  concat fv_open_uppers ++
                  concat fv_subst_freshs ++
                  concat fv_subst_lowers ++
                  concat fv_subst_notins ++
                  concat fv_subst_uppers ++ "\n" ++
                  coqSep ++ "(** * More theorems about [subst] *)\n\n" ++
                  concat subst_close_open_recs ++
                  concat subst_close_opens ++
                  (concat $ concat subst_constrs)
       }
    where
      fixSCC (AcyclicSCC n) = [canon n]
      fixSCC (CyclicSCC ns) = nmap canon ns

      aa    = analyzeAST ast
      canon = canonRoot aa
      nts   = reverse $ map fixSCC $ stronglyConnComp $ ntGraph aa


{- ----------------------------------------------------------------------- -}
{- * Theorems -}

{- | @close_rec n x e = e@ when @degree n e@. -}

close_degree_rec :: ASTAnalysis -> [NtRoot] -> M String
close_degree_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve True Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeRecName aa nt1 mv2
             ; degree   <- degreeName aa nt1 mv2
             ; return $ close_fn ++ "_" ++ degree
             }

      thm aa nt1 _ mv2 =
          do { close_fn <- closeRecName aa nt1 mv2
             ; degree   <- degreeName aa nt1 mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; n        <- newName bvarRoot
             ; x        <- newName mv2
             ; e        <- newName nt1
             ; return $ printf "forall %s %s %s,\n\
                               \  %s %s %s ->\n\
                               \  %s %s %s %s ->\n\
                               \  %s %s %s %s = %s"
                               e x n
                               degree n e
                               x mvSetNotin fv_fn e
                               close_fn n x e e
             }

{- | @close_rec k x e1 = close_rec k x e2@ implies @e1 = e2@. -}

close_inj_rec :: ASTAnalysis -> [NtRoot] -> M String
close_inj_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; e2s      <- processNt1 aaa nt1s (\_ -> newName)
       ; let branches = map (printf "destruct %s") e2s
       ; let proof = mutPfStart Prop types ++
                     "intros; " ++ (wrap $ join branches) ++
                     ";\n" ++ defaultSimp ++ printf "; eauto 2 with %s." hintDb
       ; return $ mutualLemmaText2 Immediate False Hide [hintDb] Prop names thms (repeat proof)
       }
    where
      wrap :: String -> String
      wrap str  = printf "(%s)" str
      join strs = sepStrings " || " strs

      name aa nt1 _ mv2 =
          do { close_fn <- closeRecName aa nt1 mv2
             ; return $ close_fn ++ "_inj"
             }

      thm aa nt1 _ mv2 =
          do { e2       <- newName nt1
             ; e1       <- newName nt1
             ; k        <- newName bvarRoot
             ; x        <- newName mv2
             ; close_fn <- closeRecName aa nt1 mv2
             ; return $ printf "forall %s %s %s %s,\n\
                               \  %s %s %s %s = %s %s %s %s ->\n\
                               \  %s = %s"
                               e1 e2 x k
                               close_fn k x e1 close_fn k x e2
                               e1 e2
             }

{- | @close x e1 = close x e2@ implies @e1 = e2@. -}

close_inj :: ASTAnalysis -> [NtRoot] -> M String
close_inj aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Immediate False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeName aa nt1 mv2
             ; return $ close_fn ++ "_inj"
             }

      gen aa nt1 _ mv2 =
          do { e2       <- newName nt1
             ; e1       <- newName nt1
             ; x        <- newName mv2
             ; close_fn <- closeName aa nt1 mv2
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s %s = %s %s %s ->\n\
                                 \  %s = %s"
                                 e1 e2 x
                                 close_fn x e1 close_fn x e2
                                 e1 e2
             ; let proof = printf "unfold %s; eauto 2 with %s." close_fn hintDb
             ; return (stmt, proof)
             }

{- | @close u e = e@ when @lc e@. -}

close_lc :: ASTAnalysis -> [NtRoot] -> M String
close_lc aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve True NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeName aa nt1 mv2
             ; lc       <- lcName aa nt1
             ; return $ close_fn ++ "_" ++ lc
             }

      gen aa nt1 _ mv2 =
          do { close_fn <- closeName aa nt1 mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; lc       <- lcName aa nt1
             ; x        <- newName mv2
             ; e        <- newName nt1
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s %s ->\n\
                                 \  %s %s %s %s ->\n\
                                 \  %s %s %s = %s"
                                 e x
                                 lc e
                                 x mvSetNotin fv_fn e
                                 close_fn x e e
             ; let proof = printf "unfold %s; %s." close_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @close_rec k x (open_rec k x e) = e@ when @x `notin` fv e@. -}

close_open_rec :: ASTAnalysis -> [NtRoot] -> M String
close_open_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve True Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeRecName aa nt1 mv2
             ; open_fn  <- openRecName aa nt1 mv2
             ; return $ close_fn ++ "_" ++ open_fn
             }

      thm aa nt1 nt2 mv2 =
          do { k        <- newName bvarRoot
             ; x        <- newName mv2
             ; e        <- newName nt1
             ; close_fn <- closeRecName aa nt1 mv2
             ; open_fn  <- openRecName aa nt1 mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; constr   <- getFreeVarConstr aa nt2 mv2
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s %s %s %s ->\n\
               \  %s %s %s (%s %s (%s %s) %s) = %s"
               e x k
               x mvSetNotin fv_fn e
               close_fn k x open_fn k (toName constr) x e e
             }

{- | @close x (open x e) = e@ when @x `notin` fv e@. -}

close_open :: ASTAnalysis -> [NtRoot] -> M String
close_open aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve True NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeName aa nt1 mv2
             ; open_fn  <- openName aa nt1 mv2
             ; return $ close_fn ++ "_" ++ open_fn
             }

      gen aa nt1 nt2 mv2 =
          do { x        <- newName mv2
             ; e        <- newName nt1
             ; close_fn <- closeName aa nt1 mv2
             ; open_fn  <- openName aa nt1 mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; constr   <- getFreeVarConstr aa nt2 mv2
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s %s %s %s ->\n\
                                 \  %s %s (%s (%s %s) %s) = %s"
                                 e x
                                 x mvSetNotin fv_fn e
                                 close_fn x open_fn (toName constr) x e e
             ; let proof = printf "unfold %s; unfold %s; %s."
                                  close_fn open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @degree 0 e@ implies @degree k e@. -}

degree_O :: ASTAnalysis -> [NtRoot] -> M String
degree_O aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { degree <- degreeName aa nt1 mv2
             ; return $ degree ++ "_O"
             }

      gen aa nt1 _ mv2 =
          do { k      <- newName bvarRoot
             ; e      <- newName nt1
             ; degree <- degreeName aa nt1 mv2
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s %s %s ->\n\
                                 \  %s %s %s"
                                 k e
                                 degree "O" e
                                 degree k e
             ; let proof = printf "induction %s; %s." k defaultSimp
             ; return (stmt, proof)
             }

{- | @degree k e@ implies @degree (S k) e@. -}

degree_S :: ASTAnalysis -> [NtRoot] -> M String
degree_S aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; degrees  <- processNt1Nt2Mv2 aaa nt1s (\aa nt1 _ mv2 -> degreeName aa nt1 mv2)
       ; let proof = map (finish . mutPfStart Set) degrees
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Set names thms proof
       }
    where
      finish str = str ++ defaultSimp ++ "."

      name aa nt1 _ mv2 =
          do { degree <- degreeName aa nt1 mv2
             ; return $ degree ++ "_S"
             }

      thm aa nt1 _ mv2 =
          do { k      <- newName bvarRoot
             ; e      <- newName nt1
             ; degree <- degreeName aa nt1 mv2
             ; return $ printf
               "forall %s %s,\n\
               \  %s %s %s ->\n\
               \  %s (S %s) %s"
               k e
               degree k e
               degree k e
             }

{- | @degree (S n) (close_rec n x e)@ when @degree n e@. -}

degree_close_rec :: ASTAnalysis -> [NtRoot] -> M String
degree_close_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Set types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Set names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ degree ++ "_" ++ close_fn
             }

      thm aa nt1 _ mv2 _ mv2' | mv2 == mv2' =
          do { k        <- newName bvarRoot
             ; e        <- newName nt1
             ; x        <- newName mv2'
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s %s %s ->\n\
               \  %s (S %s) (%s %s %s %s)"
               e x k
               degree k e
               degree k close_fn k x e
             }

      thm aa nt1 _ mv2 _ mv2' | otherwise =
          do { k        <- newName bvarRoot
             ; k'       <- newName bvarRoot
             ; e        <- newName nt1
             ; x        <- newName mv2'
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s %s,\n\
               \  %s %s %s ->\n\
               \  %s %s (%s %s %s %s)"
               e x k k'
               degree k e
               degree k close_fn k' x e
             }

{- | @degree 1 (close x e)@ when @degree 0 e@. -}

degree_close :: ASTAnalysis -> [NtRoot] -> M String
degree_close aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; return $ degree ++ "_" ++ close_fn
             }

      gen aa nt1 _ mv2 _ mv2' | mv2 == mv2' =
          do { e        <- newName nt1
             ; x        <- newName mv2'
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s 0 %s ->\n\
                                 \  %s 1 (%s %s %s)"
                                 e x
                                 degree e
                                 degree close_fn x e
             ; let proof = printf "unfold %s; %s." close_fn defaultSimp
             ; return (stmt, proof)
             }

      gen aa nt1 _ mv2 _ mv2' | otherwise =
          do { e        <- newName nt1
             ; x        <- newName mv2'
             ; k        <- newName bvarRoot
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s %s ->\n\
                                 \  %s %s (%s %s %s)"
                                 e x k
                                 degree k e
                                 degree k close_fn x e
             ; let proof = printf "unfold %s; %s." close_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @degree n e@ when @degree (S n) (close_rec n x e)@. -}

degree_close_inv_rec :: ASTAnalysis -> [NtRoot] -> M String
degree_close_inv_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Set types ++ defaultSimp ++
                             printf "; eauto with %s." hintDb)
       ; return $ mutualLemmaText2 Immediate False Hide [hintDb] Set names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ degree ++ "_" ++ close_fn ++ "_inv"
             }

      thm aa nt1 _ mv2 _ mv2' | mv2 == mv2' =
          do { k        <- newName bvarRoot
             ; e        <- newName nt1
             ; x        <- newName mv2'
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s (S %s) (%s %s %s %s) ->\n\
               \  %s %s %s"
               e x k
               degree k close_fn k x e
               degree k e
             }

      thm aa nt1 _ mv2 _ mv2' | otherwise =
          do { k        <- newName bvarRoot
             ; k'       <- newName bvarRoot
             ; e        <- newName nt1
             ; x        <- newName mv2'
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s %s,\n\
               \  %s %s (%s %s %s %s) ->\n\
               \  %s %s %s"
               e x k k'
               degree k close_fn k' x e
               degree k e
             }

{- | @degree 0 e@ when @degree 1 (close x e)@. -}

degree_close_inv :: ASTAnalysis -> [NtRoot] -> M String
degree_close_inv aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Immediate False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree  <- degreeName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; return $ degree ++ "_" ++ close_fn ++ "_inv"
             }

      gen aa nt1 _ mv2 _ mv2' | mv2 == mv2' =
          do { e        <- newName nt1
             ; x        <- newName mv2'
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s 1 (%s %s %s) ->\n\
                                 \  %s 0 %s"
                                 e x
                                 degree close_fn x e
                                 degree e
             ; let proof = printf "unfold %s; eauto 2 with %s." close_fn hintDb
             ; return (stmt, proof)
             }

      gen aa nt1 _ mv2 _ mv2' | otherwise =
          do { e        <- newName nt1
             ; x        <- newName mv2'
             ; k        <- newName bvarRoot
             ; degree   <- degreeName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s (%s %s %s) ->\n\
                                 \  %s %s %s"
                                 e x k
                                 degree k close_fn x e
                                 degree k e
             ; let proof = printf "unfold %s; eauto 2 with %s." close_fn hintDb
             ; return (stmt, proof)
             }

{- | @degree 0 e@ when @lc e@. -}

degree_of_lc :: ASTAnalysis -> [NtRoot] -> M String
degree_of_lc aaa nt1s =
    do { thms      <- processNt1Nt2Mv2 aaa nt1s thm
       ; names     <- processNt1Nt2Mv2 aaa nt1s name
       ; types     <- processNt1 aaa nt1s lcName
       ; h1        <- newName "H"
       ; h2        <- newName "H"
       ; freshTacs <- genFreshTacs
       ; let proof = printf "%s\
                            \intros;\n\
                            \%s\
                            \repeat (match goal with\n\
                            \          | %s : _, %s : _ |- _ => specialize %s with %s\n\
                            \        end);\n\
                            \%s; eauto with %s."
                            (mutPfStart Set types)
                            (concat freshTacs :: String)
                            h1 h2 h1 h2
                            defaultSimp hintDb
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Set names thms (repeat proof)
       }
    where
      name aa nt1 _ mv2 =
          do { degree <- degreeName aa nt1 mv2
             ; lc     <- lcName aa nt1
             ; return $ degree ++ "_of_" ++ lc
             }

      thm aa nt1 _ mv2 =
          do { degree <- degreeName aa nt1 mv2
             ; lc     <- lcName aa nt1
             ; e1     <- newName nt1
             ; return $ printf "forall %s,\n\
                               \  %s %s ->\n\
                               \  %s 0 %s"
                               e1
                               lc e1
                               degree e1
             }

      genFreshTacs =
          sequence $
          do { nt2 <- filter (canBindOver aaa (head nt1s)) (ntRoots aaa)
             ; mv2 <- mvsOfNt aaa nt2
             ; return $ do { mvt <- mvType aaa mv2;
                           ; x   <- newName mv2
                           ; return $ printf
                             "let %s := fresh \"%s\" in %s %s;\n"
                             x x (pickFreshTac mvt) x
                           }
             }

{- | @degree n (open_rec n u e)@ when
     @degree n u@ and @degree (S n) e@. -}

degree_open_rec :: ASTAnalysis -> [NtRoot] -> M String
degree_open_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Set types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Set names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree  <- degreeName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ degree ++ "_" ++ open_fn
             }

      thm aa nt1 _ mv2 nt2' mv2' | mv2 == mv2' =
          do { k       <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; degree  <- degreeName aa nt1 mv2
             ; degree' <- degreeName aa nt2' mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s (S %s) %s ->\n\
               \  %s %s %s ->\n\
               \  %s %s (%s %s %s %s)"
               e u k
               degree k e
               degree' k  u
               degree k open_fn k u e
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { k       <- newName bvarRoot
             ; k'      <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; degree  <- degreeName aa nt1 mv2
             ; degree' <- degreeName aa nt2' mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s %s,\n\
               \  %s %s %s ->\n\
               \  %s %s %s ->\n\
               \  %s %s (%s %s %s %s)"
               e u k k'
               degree k e
               degree' k  u
               degree k open_fn k' u e
             }

      thm aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { k       <- newName bvarRoot
             ; k'      <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; degree  <- degreeName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s %s,\n\
               \  %s %s %s ->\n\
               \  %s %s (%s %s %s %s)"
               e u k k'
               degree k e
               degree k open_fn k' u e
             }

{- | @degree 0 (open u e)@ when
     @degree 0 u@ and @degree 1 e@. -}

degree_open :: ASTAnalysis -> [NtRoot] -> M String
degree_open aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree  <- degreeName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; return $ degree ++ "_" ++ open_fn
             }

      gen aa nt1 _ mv2 nt2' mv2' | mv2 == mv2' =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; degree  <- degreeName aa nt1 mv2
             ; degree' <- degreeName aa nt2' mv2
             ; open_fn <- openName aa nt1 mv2'
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s 1 %s ->\n\
                                 \  %s 0 %s ->\n\
                                 \  %s 0 (%s %s %s)"
                                 e u
                                 degree e
                                 degree' u
                                 degree open_fn u e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

      gen aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; k       <- newName bvarRoot
             ; degree  <- degreeName aa nt1 mv2
             ; degree' <- degreeName aa nt2' mv2
             ; open_fn <- openName aa nt1 mv2'
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s %s ->\n\
                                 \  %s %s %s ->\n\
                                 \  %s %s (%s %s %s)"
                                 e u k
                                 degree k e
                                 degree' k u
                                 degree k open_fn u e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

      gen aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; k       <- newName bvarRoot
             ; degree  <- degreeName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s %s ->\n\
                                 \  %s %s (%s %s %s)"
                                 e u k
                                 degree k e
                                 degree k open_fn u e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @degree (S n) e@ when @degree n (open_rec n u e)@. -}

degree_open_inv_rec :: ASTAnalysis -> [NtRoot] -> M String
degree_open_inv_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Set types ++ defaultSimp ++
                             printf "; eauto with %s." hintDb)
       ; return $ mutualLemmaText2 Immediate False Hide [hintDb] Set names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree  <- degreeName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ degree ++ "_" ++ open_fn ++ "_inv"
             }

      thm aa nt1 _ mv2 nt2' mv2' | mv2 == mv2' =
          do { k       <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; degree  <- degreeName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s %s (%s %s %s %s) ->\n\
               \  %s (S %s) %s"
               e u k
               degree k open_fn k u e
               degree k e
             }

      thm aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { k       <- newName bvarRoot
             ; k'      <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; degree  <- degreeName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ printf
               "forall %s %s %s %s,\n\
               \  %s %s (%s %s %s %s) ->\n\
               \  %s %s %s"
               e u k k'
               degree k open_fn k' u e
               degree k e
             }

{- | @degree 1 e@ when @degree 0 (open u e)@. -}

degree_open_inv :: ASTAnalysis -> [NtRoot] -> M String
degree_open_inv aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { degree  <- degreeName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; return $ degree ++ "_" ++ open_fn ++ "_inv"
             }

      gen aa nt1 _ mv2 nt2' mv2' | mv2 == mv2' =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; degree  <- degreeName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s 0 (%s %s %s) ->\n\
                                 \  %s 1 %s"
                                 e u
                                 degree open_fn u e
                                 degree e
             ; let proof = printf "unfold %s; eauto 2 with %s." open_fn hintDb
             ; return (stmt, proof)
             }

      gen aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; k       <- newName bvarRoot
             ; degree  <- degreeName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s (%s %s %s) ->\n\
                                 \  %s %s %s"
                                 e u k
                                 degree k open_fn u e
                                 degree k e
             ; let proof = printf "unfold %s; eauto 2 with %s." open_fn hintDb
             ; return (stmt, proof)
             }

{- | @fv (close_rec n x e) [=] remove x (fv e)@. -}

fv_close_rec :: ASTAnalysis -> [NtRoot] -> M String
fv_close_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; proofs   <- processNt1Nt2Mv2' aaa nt1s pf
       ; let proof = map head proofs
       ; return $ mutualLemmaText2 Resolve True Hide [hintDb] Prop names thms proof
       }
    where
      pf aa _ _ mv2 _ _ =
          do { mvt      <- mvType aa mv2
             ; types    <- processNt1 aaa nt1s ntType
             ; return $ mutPfStart Prop types ++
                        defaultSimp ++ "; " ++
                        fsetdecTac ++ " " ++ mvt ++ "."
             }

      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn <- fvName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ close_fn
             }

      thm aa nt1 _ mv2 _ mv2' | mv2 == mv2' =
          do { k        <- newName bvarRoot
             ; e        <- newName nt1
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s (%s %s %s %s) [=] %s %s (%s %s)"
                        e x k
                        fv_fn close_fn k x e mvSetRemove x fv_fn e
             }

      thm aa nt1 _ mv2 _ mv2' | otherwise =
          do { k        <- newName bvarRoot
             ; e        <- newName nt1
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s (%s %s %s %s) [=] %s %s"
                        e x k
                        fv_fn close_fn k x e fv_fn e
             }

{- | @fv (close x e) [=] remove x (fv e)@. -}

fv_close :: ASTAnalysis -> [NtRoot] -> M String
fv_close aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve True NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn <- fvName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ close_fn
             }

      gen aa nt1 _ mv2 _ mv2' | mv2 == mv2' =
          do { e        <- newName nt1
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s (%s %s %s) [=] %s %s (%s %s)"
                                 e x
                                 fv_fn close_fn x e mvSetRemove x fv_fn e
             ; let proof = printf "unfold %s; %s." close_fn defaultSimp
             ; return (stmt, proof)
             }

      gen aa nt1 _ mv2 _ mv2' | otherwise =
          do { e        <- newName nt1
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s (%s %s %s) [=] %s %s"
                                 e x
                                 fv_fn close_fn x e fv_fn e
             ; let proof = printf "unfold %s; %s." close_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @fv e [<=] fv (open_rec k e' e)@. -}

fv_open_rec_lower :: ASTAnalysis -> [NtRoot] -> M String
fv_open_rec_lower aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; proofs   <- processNt1Nt2Mv2' aaa nt1s pf
       ; let proof = map head proofs
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Prop names thms proof
       }
    where
      pf aa _ _ mv2 _ _ =
          do { mvt      <- mvType aa mv2
             ; types    <- processNt1 aaa nt1s ntType
             ; return $ mutPfStart Prop types ++
                        defaultSimp ++ "; " ++
                        fsetdecTac ++ " " ++ mvt ++ "."
             }

      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn <- fvName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ open_fn ++ "_lower"
             }

      thm aa nt1 _ mv2 nt2' mv2' =
          do { k       <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; fv_fn   <- fvName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s %s [<=] %s (%s %s %s %s)"
                        e u k
                        fv_fn e fv_fn open_fn k u e
             }

{- | @fv e [<=] fv (open e' e)@. -}

fv_open_lower :: ASTAnalysis -> [NtRoot] -> M String
fv_open_lower aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn <- fvName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ open_fn ++ "_lower"
             }

      gen aa nt1 _ mv2 nt2' mv2' =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; fv_fn   <- fvName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s %s [<=] %s (%s %s %s)"
                                 e u
                                 fv_fn e fv_fn open_fn u e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @fv (open_rec n e' e) [<=] fv e' `union` fv e@. -}

fv_open_rec_upper :: ASTAnalysis -> [NtRoot] -> M String
fv_open_rec_upper aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; proofs   <- processNt1Nt2Mv2' aaa nt1s pf
       ; let proof = map head proofs
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Prop names thms proof
       }
    where
      pf aa _ _ mv2 _ _ =
          do { mvt      <- mvType aa mv2
             ; types    <- processNt1 aaa nt1s ntType
             ; return $ mutPfStart Prop types ++
                        defaultSimp ++ "; " ++
                        fsetdecTac ++ " " ++ mvt ++ "."
             }

      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn <- fvName aa nt1 mv2
             ; open_fn <- openRecName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ open_fn ++ "_upper"
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { k       <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; open_fn <- openRecName aa nt1 mv2'
             ; fv_fn   <- fvName aa nt1 mv2
             ; fv_fn2  <- fvName aa nt2' mv2
             ; return $ printf "forall %s %s %s,\n\
                               \  %s (%s %s %s %s) [<=] %s %s %s %s %s"
                        e u k
                        fv_fn open_fn k u e fv_fn2 u mvSetUnion fv_fn e
             }

      thm aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { k       <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2'
             ; open_fn <- openRecName aa nt1 mv2'
             ; fv_fn   <- fvName aa nt1 mv2
             ; return $ printf "forall %s %s %s,\n\
                               \  %s (%s %s %s %s) [<=] %s %s"
                        e u k
                        fv_fn open_fn k u e fv_fn e
             }

{- | @fv (open e' e) [<=] fv e' `union` fv e@. -}

fv_open_upper :: ASTAnalysis -> [NtRoot] -> M String
fv_open_upper aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn <- fvName aa nt1 mv2
             ; open_fn <- openName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ open_fn ++ "_upper"
             }

      gen aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; open_fn <- openName aa nt1 mv2'
             ; fv_fn   <- fvName aa nt1 mv2
             ; fv_fn2  <- fvName aa nt2' mv2
             ; let stmt = printf "forall %s %s,\n\
                               \  %s (%s %s %s) [<=] %s %s %s %s %s"
                        e u
                        fv_fn open_fn u e fv_fn2 u mvSetUnion fv_fn e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

      gen aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { e       <- newName nt1
             ; u       <- newName nt2'
             ; open_fn <- openName aa nt1 mv2'
             ; fv_fn   <- fvName aa nt1 mv2
             ; let stmt = printf "forall %s %s,\n\
                               \  %s (%s %s %s) [<=] %s %s"
                        e u
                        fv_fn open_fn u e fv_fn e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @x `notin` fv e -> fv (subst e' x e) [=] fv e@. -}

fv_subst_fresh :: ASTAnalysis -> [NtRoot] -> M String
fv_subst_fresh aaa nt1s =
    do { thms'     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names'    <- processNt1Nt2Mv2' aaa nt1s name
       ; proofs'   <- processNt1Nt2Mv2' aaa nt1s pf
       ; let thms   = filter (not . null) $ map catMaybes thms'
       ; let names  = filter (not . null) $ map catMaybes names'
       ; let proofs = filter (not . null) $ map catMaybes proofs'
       ; let proof  = map head proofs
       ; return $ mutualLemmaText2 Resolve True NoHide [hintDb] Prop names thms proof
       }
    where
      pf aa _ nt2 mv2 nt2' mv2' | mv2 == mv2' || not (canBindIn aa nt2 nt2')  =
          do { mvt      <- mvType aa mv2
             ; types    <- processNt1 aaa nt1s ntType
             ; return $ Just $ mutPfStart Prop types ++
                               defaultSimp ++ "; " ++
                               fsetdecTac ++ " " ++ mvt ++ "."
             }

      pf _ _ _ _ _ _ | otherwise = return Nothing

      name aa nt1 nt2' mv2 nt2 mv2' | mv2 == mv2' || not (canBindIn aa nt2 nt2') =
          do { fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ Just $ fv_fn ++ "_" ++ subst_fn ++ "_fresh"
             }

      name _ _ _ _ _ _ | otherwise = return Nothing

      thm aa nt1 _ mv2 nt2' mv2' | mv2 == mv2' =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ Just $ printf "forall %s %s %s,\n\
                                      \  %s %s %s %s ->\n\
                                      \  %s (%s %s %s %s) [=] %s %s"
                                      e u x
                                      x mvSetNotin fv_fn e
                                      fv_fn subst_fn u x e fv_fn e
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | not (canBindIn aa nt2 nt2') =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ Just $ printf "forall %s %s %s,\n\
                                      \  %s (%s %s %s %s) [=] %s %s"
                                      e u x
                                      fv_fn subst_fn u x e fv_fn e
             }

      thm _ _ _ _ _ _ | otherwise = return Nothing

{- | @remove x (fv e) [<=] fv (subst e' x e)@. -}

fv_subst_lower :: ASTAnalysis -> [NtRoot] -> M String
fv_subst_lower aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; proofs   <- processNt1Nt2Mv2' aaa nt1s pf
       ; let proof = map head proofs
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Prop names thms proof
       }
    where
      pf aa _ _ mv2 _ _ =
          do { mvt      <- mvType aa mv2
             ; types    <- processNt1 aaa nt1s ntType
             ; return $ mutPfStart Prop types ++
                        defaultSimp ++ "; " ++
                        fsetdecTac ++ " " ++ mvt ++ "."
             }
      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ subst_fn ++ "_lower"
             }

      thm aa nt1 _ mv2 nt2' mv2' | mv2 == mv2' =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s %s (%s %s) [<=] %s (%s %s %s %s)"
                        e u x
                        mvSetRemove x fv_fn e fv_fn subst_fn u x e
             }

      thm aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s %s [<=] %s (%s %s %s %s)"
                        e u x
                        fv_fn e fv_fn subst_fn u x e
             }

{- | @x `notin` fv (subst u x e)@ when
     @x `notin` fv u@ and @x `notin` fv e@. -}

fv_subst_notin :: ASTAnalysis -> [NtRoot] -> M String
fv_subst_notin aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; proofs   <- processNt1Nt2Mv2' aaa nt1s pf
       ; let proof = map head proofs
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Prop names thms proof
       }
    where
      pf aa _ _ mv2 _ _ =
          do { mvt      <- mvType aa mv2
             ; types    <- processNt1 aaa nt1s ntType
             ; return $ mutPfStart Prop types ++
                        defaultSimp ++ "; " ++
                        fsetdecTac ++ " " ++ mvt ++ "."
             }
      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ subst_fn ++ "_notin"
             }

      fvHyp nt2 nt2' y fv u
          | canBindIn aaa nt2 nt2' = printf "  %s %s %s %s ->\n" y mvSetNotin fv u
          | otherwise              = ""

      thm aa nt1 nt2 mv2 nt2' mv2' =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; y        <- newName mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; fv_fn'   <- fvName aa nt2' mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ printf "forall %s %s %s %s,\n\
                               \  %s %s %s %s ->\n\
                               \%s\
                               \  %s %s %s (%s %s %s %s)"
                        e u x y
                        y mvSetNotin fv_fn e
                        (fvHyp nt2 nt2' y fv_fn' u)
                        y mvSetNotin fv_fn subst_fn u x e
             }

{- | @fv (subst e' x e) [<=] fv e' `union` remove x (fv e)@. -}

fv_subst_upper :: ASTAnalysis -> [NtRoot] -> M String
fv_subst_upper aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; proofs   <- processNt1Nt2Mv2' aaa nt1s pf
       ; let proof = map head proofs
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Prop names thms proof
       }
    where
      pf aa _ _ mv2 _ _ =
          do { mvt      <- mvType aa mv2
             ; types    <- processNt1 aaa nt1s ntType
             ; return $ mutPfStart Prop types ++
                        defaultSimp ++ "; " ++
                        fsetdecTac ++ " " ++ mvt ++ "."
             }
      name aa nt1 _ mv2 _ mv2' =
          do { fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ fv_fn ++ "_" ++ subst_fn ++ "_upper"
             }

      thm aa nt1 _ mv2 nt2' mv2' | mv2 == mv2' =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; fv_fn2   <- fvName aa nt2' mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s (%s %s %s %s) [<=] %s %s %s %s %s (%s %s)"
                        e u x
                        fv_fn subst_fn u x e fv_fn2 u mvSetUnion mvSetRemove x fv_fn e
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; fv_fn2   <- fvName aa nt2' mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s (%s %s %s %s) [<=] %s %s %s %s %s"
                        e u x
                        fv_fn subst_fn u x e fv_fn2 u mvSetUnion fv_fn e
             }

      thm aa nt1 _ mv2 nt2' mv2' | otherwise =
          do { e        <- newName nt1
             ; u        <- newName nt2'
             ; x        <- newName mv2'
             ; fv_fn    <- fvName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2'
             ; return $ printf "forall %s %s %s,\n\
                               \  %s (%s %s %s %s) [<=] %s %s"
                        e u x
                        fv_fn subst_fn u x e fv_fn e
             }

{- | @degree 0 e@ implies @lc e@.

   Implementation note (BEA): This theorem is downright painful.
   Due to its structure, we need to assemble everything by hand.

   XXX BEA: Consider making \"size induction\" its own combinator. -}

lc_of_degree :: ASTAnalysis -> [NtRoot] -> M String
lc_of_degree aaa nt1s =
    if not (isOpenable aaa (head nt1s))
    then return ""
    else
    do { i     <- newName "i"
       ; h     <- newName "H"
       ; thms  <- processNt1 aaa nt1s (thm i)
       ; names <- processNt1 aaa nt1s name
       ; types <- processNt1 aaa nt1s ntType
       ; let mut_name = sepStrings "_" names ++ "_size_mutual"
       ; let mut_stms = printf "forall %s,\n%s" i (sepStrings " *\n" $ map wrap thms)
       ; let proof = printf "intros %s; pattern %s; apply %s;\n\
                            \clear %s; intros %s %s;\n\
                            \%s\
                            \%s;\n\
                            \(* non-trivial cases *)\n\
                            \constructor; %s; %s;\n\
                            \(* instantiate the size *)\n\
                            \match goal with\n\
                            \  | |- _ = _ => reflexivity\n\
                            \  | _ => idtac\n\
                            \end;\n\
                            \(* everything should be easy now *)\n\
                            \%s."
                            i i ltWfRec
                            i i h
                            (mutPfStart Set types) defaultSimp
                            defaultSimp eapplyFirst
                            defaultSimp
       ; gens <- processNt1 aaa nt1s (gen mut_name)
       ; return $ lemmaText  NoResolve False Hide [] mut_name mut_stms proof ++
                  lemmaText2 Resolve False NoHide [hintDb] [names] [gens]
       }
    where
      wrap s = "(" ++ s ++ ")"

      name aa nt1 =
          do { lc <- lcName aa nt1
             ; return $ lc ++ "_of_degree"
             }

      thm i aa nt1 =
          do { e    <- newName nt1
             ; lc   <- lcName aa nt1
             ; size <- sizeName aa nt1
             ; hyps <- processNt1Nt2Mv2 aa [nt1] (hyp e)
             ; return $ printf "forall %s,\n\
                               \  %s %s = %s ->\n\
                               \%s\
                               \  %s %s"
                               e
                               size e i
                               (concat $ concat hyps)
                               lc e
             }

      hyp e aa nt1 _ mv2 =
          do { degree <- degreeName aa nt1 mv2
             ; return $ "  " ++ degree ++ " 0 " ++ e ++ " ->\n"
             }

      gen n aa nt1 =
          do { e    <- newName nt1
             ; lc   <- lcName aa nt1
             ; hyps <- processNt1Nt2Mv2 aa [nt1] (hyp e)
             ; size <- sizeName aa nt1
             ; let stmt = printf "forall %s,\n\
                                 \%s\
                                 \  %s %s"
                                 e
                                 (concat $ concat hyps)
                                 lc e
             ; let proof = printf "intros %s; intros;\n\
                                  \pose proof (%s (%s %s));\n\
                                  \intuition eauto."
                                  e
                                  n size e
             ; return (stmt, proof)
             }

{- | "Existential" constructors for @lc@. -}

lc_exists :: ASTAnalysis -> [NtRoot] -> M [String]
lc_exists aaa nt1s =
    sequence $ do { nt1                      <- nt1s
                  ; (Syntax _ _ cs)          <- [runM $ getSyntax aaa nt1]
                  ; c@(SConstr _ _ _ args _) <- cs
                  ; when (not (hasBindingArg args)) (fail "nothing to do")
                  ; return $ local $ thm aaa nt1 c
                  }
    where
      thm aa nt1 c@(SConstr pos _ _ args _) =
          do { lc     <- lcName aa nt1
             ; glomps <- mapM (glomp aa pos) args
             ; let (mvs, nts, hyps) = unzip3 glomps
             ; let stmt  = printf "forall %s %s,\n\
                                  \%s\
                                  \  %s (%s %s)"
                                  (sepStrings " " $ catMaybes mvs) (sepStrings " " nts)
                                  (concat (catMaybes hyps) :: String)
                                  lc (toName c) (sepStrings " " nts)
             ; base <- lcConstrName aa c nt1
             ; let name  = base ++ "_exists"
             ; let proof = defaultSimp ++ printf "; eauto 10 with %s." hintDb
             ; return $ lemmaText Resolve False NoHide [hintDb] name stmt proof
             }

      glomp _ pos IndexArg  = fail $ show pos ++ ": Internal error (lc_exists / IndexArg)."
      glomp _ pos (MvArg _) = fail $ show pos ++ ": Internal error (lc_exists / MvArg)."

      glomp aa _ (NtArg nt)
          | isOpenable aa nt =
              do { n  <- newName nt
                 ; lc <- lcName aa nt
                 ; return $ (Nothing, n, Just (printf "  %s %s ->\n" lc n))
                 }
          | otherwise =
              do { n <- newName nt
                 ; return $ (Nothing, n, Nothing)
                 }

      glomp aa _ (BindingArg mv' nt' nt) =
          do { n       <- newName nt
             ; x       <- newName mv'
             ; lc      <- lcName aa nt
             ; open_fn <- openName aa nt mv'
             ; constr  <- getFreeVarConstr aa nt' mv'
             ; return $ (Just x, n, Just (printf "  %s (%s (%s %s) %s) ->\n"
                                                 lc open_fn (toName constr) x n))
             }

{- | @(pf1 pf2 : lc e) -> pf1 = pf2@. -}

lc_unique :: ASTAnalysis -> [NtRoot] -> M String
lc_unique aaa nt1s =
    if not (isOpenable aaa (head nt1s))
    then return ""
    else
    do { pf1      <- newName "proof"
       ; pf2      <- newName "proof"
       ; thms     <- processNt1 aaa nt1s (thm pf1 pf2)
       ; names    <- processNt1 aaa nt1s name
       ; types    <- processNt1 aaa nt1s lcName
       ; let proof = mutPfStart Prop types ++
                     printf
                     "intros; dependent destruction %s; %s; auto using %s."
                     pf2 defaultSimp funExtEq
       ; return $ mutualLemmaText Resolve False NoHide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 =
          do { lc <- lcName aa nt1
             ; return $ lc ++ "_unique"
             }

      thm pf1 pf2 aa nt1 =
          do { e   <- newName nt1
             ; lc  <- lcName aa nt1
             ; return $ printf "forall %s (%s %s : %s %s), %s = %s"
                               e pf1 pf2 lc e pf1 pf2
             }

{- | @open_rec k x (close_rec k x e) = e@ -}

open_close_rec :: ASTAnalysis -> [NtRoot] -> M String
open_close_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve True Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeRecName aa nt1 mv2
             ; open_fn  <- openRecName aa nt1 mv2
             ; return $ open_fn ++ "_" ++ close_fn
             }

      thm aa nt1 nt2 mv2 =
          do { k        <- newName bvarRoot
             ; x        <- newName mv2
             ; e        <- newName nt1
             ; close_fn <- closeRecName aa nt1 mv2
             ; open_fn  <- openRecName aa nt1 mv2
             ; constr   <- getFreeVarConstr aa nt2 mv2
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s %s (%s %s) (%s %s %s %s) = %s"
               e x k
               open_fn k (toName constr) x close_fn k x e e
             }

{- | @open x (close x e) = e@ -}

open_close :: ASTAnalysis -> [NtRoot] -> M String
open_close aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve True NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeName aa nt1 mv2
             ; open_fn  <- openName aa nt1 mv2
             ; return $ open_fn ++ "_" ++ close_fn
             }

      gen aa nt1 nt2 mv2 =
          do { x        <- newName mv2
             ; e        <- newName nt1
             ; close_fn <- closeName aa nt1 mv2
             ; open_fn  <- openName aa nt1 mv2
             ; constr   <- getFreeVarConstr aa nt2 mv2
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s (%s %s) (%s %s %s) = %s"
                                 e x
                                 open_fn (toName constr) x close_fn x e e
             ; let proof = printf "unfold %s; unfold %s; %s."
                                  close_fn open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @open_rec n u e = e@ when @degree n e@. -}

open_degree_rec :: ASTAnalysis -> [NtRoot] -> M String
open_degree_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve True Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { open_fn <- openRecName aa nt1 mv2
             ; degree  <- degreeName aa nt1 mv2
             ; return $ open_fn ++ "_" ++ degree
             }

      thm aa nt1 nt2 mv2 =
          do { open_fn <- openRecName aa nt1 mv2
             ; degree  <- degreeName aa nt1 mv2
             ; n <- newName bvarRoot
             ; u <- newName nt2
             ; e <- newName nt1
             ; return $ printf "forall %s %s %s,\n\
                               \  %s %s %s ->\n\
                               \  %s %s %s %s = %s"
                               e u n
                               degree n e
                               open_fn n u e e
             }

{- | @open_rec k x e1 = open_rec k x e2@ implies @e1 = e2@ when
     @x `notin` fv e1 `union` fv e2@. -}

open_inj_rec :: ASTAnalysis -> [NtRoot] -> M String
open_inj_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; e2s      <- processNt1 aaa nt1s (\_ -> newName)
       ; let branches = map (printf "destruct %s") e2s
       ; let proof = mutPfStart Prop types ++
                     "intros; " ++ (wrap $ join branches) ++
                     ";\n" ++ defaultSimp ++ printf "; eauto 2 with %s." hintDb
       ; return $ mutualLemmaText2 Immediate False Hide [hintDb] Prop names thms (repeat proof)
       }
    where
      wrap :: String -> String
      wrap str  = printf "(%s)" str
      join strs = sepStrings " || " strs

      name aa nt1 _ mv2 =
          do { open_fn <- openRecName aa nt1 mv2
             ; return $ open_fn ++ "_inj"
             }

      thm aa nt1 nt2 mv2 =
          do { e2       <- newName nt1
             ; e1       <- newName nt1
             ; k        <- newName bvarRoot
             ; x        <- newName mv2
             ; open_fn  <- openRecName aa nt1 mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; constr   <- getFreeVarConstr aa nt2 mv2
             ; return $ printf "forall %s %s %s %s,\n\
                               \  %s %s %s %s ->\n\
                               \  %s %s %s %s ->\n\
                               \  %s %s (%s %s) %s = %s %s (%s %s) %s ->\n\
                               \  %s = %s"
                               e1 e2 x k
                               x mvSetNotin fv_fn e1
                               x mvSetNotin fv_fn e2
                               open_fn k (toName constr) x e1 open_fn k (toName constr) x e2
                               e1 e2
             }

{- | @open x e1 = open x e2@ implies @e1 = e2@ when
     @x `notin` fv e1 `union` fv e2@. -}

open_inj :: ASTAnalysis -> [NtRoot] -> M String
open_inj aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Immediate False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { open_fn <- openName aa nt1 mv2
             ; return $ open_fn ++ "_inj"
             }

      gen aa nt1 nt2 mv2 =
          do { e2       <- newName nt1
             ; e1       <- newName nt1
             ; x        <- newName mv2
             ; open_fn  <- openName aa nt1 mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; constr   <- getFreeVarConstr aa nt2 mv2
             ; let stmt = printf"forall %s %s %s,\n\
                               \  %s %s %s %s ->\n\
                               \  %s %s %s %s ->\n\
                               \  %s (%s %s) %s = %s (%s %s) %s ->\n\
                               \  %s = %s"
                               e1 e2 x
                               x mvSetNotin fv_fn e1
                               x mvSetNotin fv_fn e2
                               open_fn (toName constr) x e1 open_fn (toName constr) x e2
                               e1 e2
             ; let proof = printf "unfold %s; eauto 2 with %s." open_fn hintDb
             ; return (stmt, proof)
             }

{- | @open u e = e@ when @lc e@. -}

open_lc :: ASTAnalysis -> [NtRoot] -> M String
open_lc aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve True NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { open_fn <- openName aa nt1 mv2
             ; lc      <- lcName aa nt1
             ; return $ open_fn ++ "_" ++ lc
             }

      gen aa nt1 nt2 mv2 =
          do { open_fn <- openName aa nt1 mv2
             ; lc      <- lcName aa nt1
             ; u <- newName nt2
             ; e <- newName nt1
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s %s ->\n\
                                 \  %s %s %s = %s"
                                 e u
                                 lc e
                                 open_fn u e e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @size (close_rec n x e) = size e@. -}

size_close_rec :: ASTAnalysis -> [NtRoot] -> M String
size_close_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve True Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeRecName aa nt1 mv2
             ; size_fn  <- sizeName aa nt1
             ; return $ size_fn ++ "_" ++ close_fn
             }

      thm aa nt1 _ mv2 =
          do { k        <- newName bvarRoot
             ; x        <- newName mv2
             ; e        <- newName nt1
             ; close_fn <- closeRecName aa nt1 mv2
             ; size_fn  <- sizeName aa nt1
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s (%s %s %s %s) = %s %s"
               e x k size_fn close_fn k x e size_fn e
             }

{- | @size (close e x) = size e@. -}

size_close :: ASTAnalysis -> [NtRoot] -> M String
size_close aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve True NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { close_fn <- closeName aa nt1 mv2
             ; size_fn  <- sizeName aa nt1
             ; return $ size_fn ++ "_" ++ close_fn
             }

      gen aa nt1 _ mv2 =
          do { x        <- newName mv2
             ; e        <- newName nt1
             ; close_fn <- closeName aa nt1 mv2
             ; size_fn  <- sizeName aa nt1
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s (%s %s %s) = %s %s"
                                 e x size_fn close_fn x e size_fn e
             ; let proof = printf "unfold %s; %s." close_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @1 <= size e@. -}

size_min :: ASTAnalysis -> [NtRoot] -> M String
size_min aaa nt1s =
    do { thms     <- processNt1 aaa nt1s thm
       ; names    <- processNt1 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = mutPfStart Prop types ++ defaultSimp ++ "."
       ; return $ mutualLemmaText Resolve False NoHide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 =
          do { fn <- sizeName aa nt1
             ; return $ fn ++ "_min"
             }

      thm aa nt1 =
          do { e <- newName nt1
             ; n <- sizeName aa nt1
             ; return $ printf "forall %s, 1 <= %s %s" e n e
             }

{- | @size e <= size (open_rec n e' e)@. -}

size_open_rec :: ASTAnalysis -> [NtRoot] -> M String
size_open_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { open_fn <- openRecName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; return $ size_fn ++ "_" ++ open_fn
             }

      thm aa nt1 nt2 mv2 =
          do { k       <- newName bvarRoot
             ; e       <- newName nt1
             ; u       <- newName nt2
             ; open_fn <- openRecName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; return $ printf "forall %s %s %s,\n\
                               \  %s %s <= %s (%s %s %s %s)"
                        e u k
                        size_fn e size_fn open_fn k u e
             }

{- | @size e <= size (open e' e)@. -}

size_open :: ASTAnalysis -> [NtRoot] -> M String
size_open aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { open_fn <- openName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; return $ size_fn ++ "_" ++ open_fn
             }

      gen aa nt1 nt2 mv2 =
          do { open_fn <- openName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; e       <- newName nt1;
             ; u       <- newName nt2;
             ; open    <- openName aa nt1 mv2
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s %s <= %s (%s %s %s)"
                                 e u
                                 size_fn e size_fn open_fn u e
             ; let proof = printf "unfold %s; %s." open defaultSimp
             ; return (stmt, proof)
             }

{- | @size (open_rec n (var x) e) = size e@. -}

size_open_rec_var :: ASTAnalysis -> [NtRoot] -> M String
size_open_rec_var aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve True Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { open_fn <- openRecName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; return $ size_fn ++ "_" ++ open_fn ++ "_var"
             }

      thm aa nt1 nt2 mv2 =
          do { open_fn <- openRecName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; constr  <- getFreeVarConstr aa nt2 mv2
             ; e       <- newName nt1
             ; x       <- newName mv2
             ; k       <- newName bvarRoot
             ; return $ printf
               "forall %s %s %s,\n\
               \  %s (%s %s (%s %s) %s) = %s %s"
               e x k
               size_fn open_fn k (toName constr) x e size_fn e
             }

{- | @size (open (var x) e) = size e@. -}

size_open_var :: ASTAnalysis -> [NtRoot] -> M String
size_open_var aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve True NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { open_fn <- openName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; return $ size_fn ++ "_" ++ open_fn ++ "_var"
             }

      gen aa nt1 nt2 mv2 =
          do { open_fn <- openName aa nt1 mv2
             ; size_fn <- sizeName aa nt1
             ; constr  <- getFreeVarConstr aa nt2 mv2
             ; e       <- newName nt1
             ; x       <- newName mv2
             ; let stmt = printf "forall %s %s,\n\
                                 \  %s (%s (%s %s) %s) = %s %s"
                                 e x
                                 size_fn open_fn (toName constr) x e size_fn e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @subxt u x (close_rec k y e) = close_rec k y (subst u x e)@
     when @x <> y@ and @y `notin` fv u@ and @degree k u@. -}

subst_close_rec :: ASTAnalysis -> [NtRoot] -> M String
subst_close_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; return $ subst_fn ++ "_" ++ close_fn
             }

      neq mv2 mv2' x y | mv2 == mv2' = printf "  %s <> %s ->\n" x y
                       | otherwise   = ""

      fv nt2 nt2' y fv_fn u
          | canBindIn aaa nt2' nt2 = printf "  %s %s %s %s ->\n" y mvSetNotin fv_fn u
          | otherwise              = ""

      deg nt2 nt2' d k u
          | canBindIn aaa nt2' nt2 = printf "  %s %s %s ->\n" d k u
          | otherwise              = ""

      thm aa nt1 nt2 mv2 nt2' mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; fv_fn    <- fvName aa nt2 mv2'
             ; degree   <- degreeName aa nt2 mv2'
             ; x        <- newName mv2'
             ; y        <- newName mv2
             ; k        <- newName bvarRoot
             ; u        <- newName nt2
             ; e        <- newName nt1
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \%s\
                               \%s\
                               \%s\
                               \  %s %s %s (%s %s %s %s) = %s %s %s (%s %s %s %s)"
                               e u x y k
                               (deg nt2 nt2' degree k u)
                               (neq mv2 mv2' x y)
                               (fv nt2 nt2' y fv_fn u)
                               subst_fn u x close_fn k y e
                               close_fn k y subst_fn u x e
             }

{- | @subxt u x (close y e) = close y (subst u x e)@
     when @x <> y@ and @y `notin` fv u@ and @lc u@. -}

subst_close :: ASTAnalysis -> [NtRoot] -> M String
subst_close aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; return $ subst_fn ++ "_" ++ close_fn
             }

      neq mv2 mv2' x y | mv2 == mv2' = printf "  %s <> %s ->\n" x y
                       | otherwise   = ""

      fv nt2 nt2' y fv_fn u
          | canBindIn aaa nt2' nt2 = printf "  %s %s %s %s ->\n" y mvSetNotin fv_fn u
          | otherwise              = ""

      gen aa nt1 nt2 mv2 nt2' mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; fv_fn    <- fvName aa nt2 mv2'
             ; lc       <- lcName aa nt2
             ; x        <- newName mv2'
             ; y        <- newName mv2
             ; u        <- newName nt2
             ; e        <- newName nt1
             ; let stmt = printf "forall %s %s %s %s,\n\
                                 \  %s %s ->\
                                 \%s\
                                 \%s\
                                 \  %s %s %s (%s %s %s) = %s %s (%s %s %s %s)"
                                 e u x y
                                 lc u
                                 (neq mv2 mv2' x y)
                                 (fv nt2 nt2' y fv_fn u)
                                 subst_fn u x close_fn y e
                                 close_fn y subst_fn u x e
             ; let proof = printf "unfold %s; %s." close_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @subst u x e@ = @close_rec k z (subst u x (open_rec k (var z) e))@
     when @z `notin` fv u `union` fv e `union` { x }@ and @degree k u@. -}

subst_close_open_rec :: ASTAnalysis -> [NtRoot] -> M String
subst_close_open_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Set types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Set names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; open_fn  <- openRecName aa nt1 mv2'
             ; return $ sepStrings "_" [subst_fn, close_fn, open_fn]
             }

      neq mv2 mv2' z x | mv2 == mv2' = printf "  %s <> %s ->\n" z x
                       | otherwise   = ""

      fv nt nt' z fv_fn t
          | canBindIn aaa nt' nt = printf "  %s %s %s %s ->\n" z mvSetNotin fv_fn t
          | otherwise            = ""

      deg nt nt' d k t
          | canBindIn aaa nt' nt = printf "  %s %s %s ->\n" d k t
          | otherwise            = ""

      thm aa nt1 nt2 mv2 nt2' mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeRecName aa nt1 mv2'
             ; open_fn  <- openRecName aa nt1 mv2'
             ; degree   <- degreeName aa nt2 mv2'
             ; u        <- newName nt2
             ; x        <- newName mv2
             ; z        <- newName mv2'
             ; e        <- newName nt1
             ; k        <- newName bvarRoot
             ; fv_fn    <- fvName aa nt1 mv2'
             ; fv_fn'   <- fvName aa nt2 mv2'
             ; constr   <- getFreeVarConstr aa nt2' mv2'
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \%s\
                               \%s\
                               \%s\
                               \%s\
                               \  %s %s %s %s = %s %s %s (%s %s %s (%s %s (%s %s) %s))"
                               e u x z k
                               (fv nt1 nt2' z fv_fn e)
                               (fv nt2 nt2' z fv_fn' u)
                               (neq mv2 mv2' z x)
                               (deg nt2 nt2' degree k u)
                               subst_fn u x e
                               close_fn k z subst_fn u x open_fn k (toName constr) z e
             }

{- | @subst u x e@ = @close_rec k z (subst u x (open_rec k (var z) e))@
     when @z `notin` fv u `union` fv e `union` { x }@ and @lc u@. -}

subst_close_open :: ASTAnalysis -> [NtRoot] -> M String
subst_close_open aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; open_fn  <- openName aa nt1 mv2'
             ; return $ sepStrings "_" [subst_fn, close_fn, open_fn]
             }

      neq mv2 mv2' z x | mv2 == mv2' = printf "  %s <> %s ->\n" z x
                       | otherwise   = ""

      fv nt nt' z fv_fn t
          | canBindIn aaa nt' nt = printf "  %s %s %s %s ->\n" z mvSetNotin fv_fn t
          | otherwise            = ""

      lcHyp nt lc t | isOpenable aaa nt = printf "  %s %s ->\n" lc t
                    | otherwise         = ""

      gen aa nt1 nt2 mv2 nt2' mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; close_fn <- closeName aa nt1 mv2'
             ; open_fn  <- openName aa nt1 mv2'
             ; lc       <- lcName aa nt2
             ; u        <- newName nt2
             ; x        <- newName mv2
             ; z        <- newName mv2'
             ; e        <- newName nt1
             ; fv_fn    <- fvName aa nt1 mv2'
             ; fv_fn'   <- fvName aa nt2 mv2'
             ; constr   <- getFreeVarConstr aa nt2' mv2'
             ; let stmt = printf "forall %s %s %s %s,\n\
                                 \%s\
                                 \%s\
                                 \%s\
                                 \%s\
                                 \  %s %s %s %s = %s %s (%s %s %s (%s (%s %s) %s))"
                                 e u x z
                                 (fv nt1 nt2' z fv_fn e)
                                 (fv nt2 nt2' z fv_fn' u)
                                 (neq mv2 mv2' z x)
                                 (lcHyp nt2 lc u)
                                 subst_fn u x e
                                 close_fn z subst_fn u x open_fn (toName constr) z e
             ; let proof = printf "unfold %s; unfold %s; %s." close_fn open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | How @subst@ commutes with binding constructors. -}

subst_constr :: ASTAnalysis -> [NtRoot] -> M [String]
subst_constr aaa nt1s =
    sequence $ do { nt1 <- nt1s
                  ; nt2 <- filter (canBindOver aaa nt1) (ntRoots aaa)
                  ; mv2 <- mvsOfNt aaa nt2
                  ; (Syntax _ _ cs)          <- [runM $ getSyntax aaa nt1]
                  ; c@(SConstr _ _ _ args _) <- cs
                  ; when (not (hasBindingArg args)) (fail "nothing to do")
                  ; return $ local $ thm aaa nt1 nt2 mv2 c
                  }
    where
      thm aa nt1 nt2 mv2 c@(SConstr pos _ _ args _) =
          do { subst_fn <- substName aa nt1 mv2
             ; lc       <- lcName aa nt2
             ; u        <- newName nt2
             ; x        <- newName mv2
             ; glomps   <- mapM (glomp aa pos nt2 mv2 u x) args
             ; let (mvs, nts, args', freshes) = unzip4 glomps
             ; let stmt  = printf "forall %s %s %s %s,\n\
                                  \%s\
                                  \%s\
                                  \  %s %s %s (%s %s) = %s %s"
                                  (sepStrings " " $ catMaybes mvs) (sepStrings " " nts) u x
                                  (lcHyp nt2 lc u)
                                  (concat $ catMaybes freshes)
                                  subst_fn u x (toName c) (sepStrings " " nts)
                                  (toName c) (sepStrings " " $ map wrap args')
             ; let proof = defaultSimp ++ "."
             ; let name  = subst_fn ++ "_" ++ (toName c)
             ; return $ lemmaText Resolve False NoHide [hintDb] name stmt proof
             }

      unzip4 []             = ([], [], [], [])
      unzip4 ((a,b,c,d):xs) = (a:as,b:bs,c:cs,d:ds)
          where
            (as,bs,cs,ds) = unzip4 xs

      wrap s = "(" ++ s ++ ")"

      lcHyp nt2 lc u | isOpenable aaa nt2 = printf "  %s %s ->\n" lc u
                     | otherwise          = ""

      glomp _ pos _ _ _ _ IndexArg  = fail $ show pos ++ ": Internal error (lc_exists / IndexArg)."
      glomp _ pos _ _ _ _ (MvArg _) = fail $ show pos ++ ": Internal error (lc_exists / MvArg)."

      glomp aa _ nt2 mv2 u x (NtArg nt)
          | canBindIn aa nt2 nt =
              do { n  <- newName nt
                 ; subst_fn <- substName aa nt mv2
                 ; return $ (Nothing, n, printf "%s %s %s %s" subst_fn u x n, Nothing)
                 }
          | otherwise =
              do { n <- newName nt
                 ; return $ (Nothing, n, n, Nothing)
                 }

      glomp aa _ nt2 mv2 u x (BindingArg mv' nt' nt)
          | canBindIn aa nt2 nt =
              do { n <- newName nt
                 ; z <- newName mv'
                 ; close_fn <- closeName aa nt mv'
                 ; open_fn  <- openName aa nt mv'
                 ; subst_fn <- substName aa nt mv2
                 ; constr   <- getFreeVarConstr aa nt' mv'
                 ; fv_fnu   <- fvName aa nt2 mv'
                 ; fv_fnn   <- fvName aa nt mv'
                 ; let fvu = if canBindIn aa nt' nt2
                             then Just (printf "%s %s" fv_fnu u)
                             else Nothing
                 ; let fvn = if canBindIn aa nt' nt
                             then Just (printf "%s %s" fv_fnn n)
                             else Nothing
                 ; let fvz = if mv' == mv2
                             then Just (printf "%s %s" mvSetSingleton x)
                             else Nothing
                 ; let fresh = catMaybes [fvu, fvn, fvz]
                 ; let hyp = if null fresh
                             then ""
                             else printf "  %s %s %s ->\n" z mvSetNotin (sepStrings (" " ++ mvSetUnion ++ " ") fresh)
                 ; return $ (Just z, n, printf "%s %s (%s %s %s (%s (%s %s) %s))"
                                               close_fn z
                                               subst_fn u x
                                               open_fn (toName constr) z n,
                                        Just hyp)
                 }
          | otherwise =
              do { n <- newName nt
                 ; return $ (Nothing, n, n, Nothing)
                 }

{- | @degree n (subst u x e)@ when @degree n u@ and @degree n e@. -}

subst_degree :: ASTAnalysis -> [NtRoot] -> M String
subst_degree aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Set types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Set names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; degree   <- degreeName aa nt1 mv2'
             ; return $ subst_fn ++ "_" ++ degree
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2' nt2 =
          do { k         <- newName bvarRoot
             ; e1        <- newName nt1
             ; e2        <- newName nt2
             ; x         <- newName mv2
             ; subst_fn  <- substName aa nt1 mv2
             ; degree    <- degreeName aa nt1 mv2'
             ; degree'   <- degreeName aa nt2 mv2'
             ; return $ printf "forall %s %s %s %s,\n\
                               \  %s %s %s ->\n\
                               \  %s %s %s ->\n\
                               \  %s %s (%s %s %s %s)"
                               e1 e2 x k
                               degree k e1
                               degree' k e2
                               degree k subst_fn e2 x e1
             }

      thm aa nt1 nt2 mv2 _ mv2' | otherwise =
          do { k         <- newName bvarRoot
             ; e1        <- newName nt1
             ; e2        <- newName nt2
             ; x         <- newName mv2
             ; subst_fn  <- substName aa nt1 mv2
             ; degree    <- degreeName aa nt1 mv2'
             ; return $ printf "forall %s %s %s %s,\n\
                               \  %s %s %s ->\n\
                               \  %s %s (%s %s %s %s)"
                               e1 e2 x k
                               degree k e1
                               degree k subst_fn e2 x e1
             }

{- | @subst u x e = e@ when @x `notin` fv e@. -}

subst_fresh :: ASTAnalysis -> [NtRoot] -> M String
subst_fresh aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve True NoHide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { subst_fn <- substName aa nt1 mv2
             ; return $ subst_fn ++ "_fresh"
             }

      thm aa nt1 nt2 mv2 =
          do { subst_fn <- substName aa nt1 mv2
             ; fv_fn    <- fvName aa nt1 mv2
             ; u        <- newName nt2
             ; x        <- newName mv2
             ; e        <- newName nt1
             ; return $ printf "forall %s %s %s,\n\
                               \  %s %s %s %s ->\n\
                               \  %s %s %s %s = %s"
                               e u x
                               x mvSetNotin fv_fn e
                               subst_fn u x e e
             }

{- | @lc (subst u x e)@ when @lc u@ and @lc e@. -}

subst_lc :: ASTAnalysis -> [NtRoot] -> M String
subst_lc aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { lc       <- lcName aa nt1
             ; subst_fn <- substName aa nt1 mv2
             ; return $ subst_fn ++ "_" ++ lc
             }

      gen aa nt1 nt2 mv2 =
          do { e1       <- newName nt1
             ; e2       <- newName nt2
             ; x        <- newName mv2
             ; lc       <- lcName aa nt1
             ; lc'      <- lcName aa nt2
             ; subst_fn <- substName aa nt1 mv2
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s ->\n\
                                 \  %s %s ->\n\
                                 \  %s (%s %s %s %s)"
                                 e1 e2 x
                                 lc e1
                                 lc' e2
                                 lc subst_fn e2 x e1
             ; let proof = printf "%s." defaultSimp
             ; return (stmt, proof)
             }

{- | @subst u x (open_rec n v e) = open_rec n (subst u x v) (subst u x e)@
     when @lc u@. -}

subst_open_rec :: ASTAnalysis -> [NtRoot] -> M String
subst_open_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; open_fn  <- openRecName aa nt1 mv2'
             ; return $ subst_fn ++ "_" ++ open_fn
             }

      lcHyp nt2 nt2' lc u
          | canBindIn aaa nt2' nt2 = printf "  %s %s ->\n" lc u
          | otherwise              = ""

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { subst_fn  <- substName aa nt1 mv2
             ; open_fn   <- openRecName aa nt1 mv2'
             ; u         <- newName nt2
             ; v         <- newName nt2'
             ; x         <- newName mv2
             ; e         <- newName nt1
             ; k         <- newName bvarRoot
             ; subst_fn' <- substName aa nt2' mv2
             ; lc        <- lcName aa nt2
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \%s\
                               \  %s %s %s (%s %s %s %s) = %s %s (%s %s %s %s) (%s %s %s %s)"
                               e u v x k
                               (lcHyp nt2 nt2' lc u)
                               subst_fn u x open_fn k v e
                               open_fn k subst_fn' u x v subst_fn u x e
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | otherwise =
          do { subst_fn  <- substName aa nt1 mv2
             ; open_fn   <- openRecName aa nt1 mv2'
             ; u         <- newName nt2
             ; v         <- newName nt2'
             ; x         <- newName mv2
             ; e         <- newName nt1
             ; k         <- newName bvarRoot
             ; lc        <- lcName aa nt2
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \%s\
                               \  %s %s %s (%s %s %s %s) = %s %s %s (%s %s %s %s)"
                               e u v x k
                               (lcHyp nt2 nt2' lc u)
                               subst_fn u x open_fn k v e
                               open_fn k v subst_fn u x e
             }

{- | @subst u x (open v e) = open (subst u x v) (subst u x e)@
     when @lc u@. -}

subst_open :: ASTAnalysis -> [NtRoot] -> M String
subst_open aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; open_fn  <- openName aa nt1 mv2'
             ; return $ subst_fn ++ "_" ++ open_fn
             }

      lcHyp nt2 nt2' lc u
          | canBindIn aaa nt2' nt2 = printf "  %s %s ->\n" lc u
          | otherwise              = ""

      gen aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { subst_fn  <- substName aa nt1 mv2
             ; open_fn   <- openName aa nt1 mv2'
             ; u         <- newName nt2
             ; v         <- newName nt2'
             ; x         <- newName mv2
             ; e         <- newName nt1
             ; subst_fn' <- substName aa nt2' mv2
             ; lc        <- lcName aa nt2
             ; let stmt = printf "forall %s %s %s %s,\n\
                                 \%s\
                                 \  %s %s %s (%s %s %s) = %s (%s %s %s %s) (%s %s %s %s)"
                                 e u v x
                                 (lcHyp nt2 nt2' lc u)
                                 subst_fn u x open_fn v e
                                 open_fn subst_fn' u x v subst_fn u x e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

      gen aa nt1 nt2 mv2 nt2' mv2' | otherwise =
          do { subst_fn  <- substName aa nt1 mv2
             ; open_fn   <- openName aa nt1 mv2'
             ; u         <- newName nt2
             ; v         <- newName nt2'
             ; x         <- newName mv2
             ; e         <- newName nt1
             ; lc        <- lcName aa nt2
             ; let stmt = printf "forall %s %s %s %s,\n\
                                 \%s\
                                 \  %s %s %s (%s %s %s) = %s %s (%s %s %s %s)"
                                 e u v x
                                 (lcHyp nt2 nt2' lc u)
                                 subst_fn u x open_fn v e
                                 open_fn v subst_fn u x e
             ; let proof = printf "unfold %s; %s." open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @subst u x (open (var y) e) = open (var y) (subst u x e)@
      when @lc u@ and @x <> y@. -}

subst_open_var :: ASTAnalysis -> [NtRoot] -> M String
subst_open_var aaa nt1s =
    do { gens     <- processNt1Nt2Mv2' aaa nt1s gen
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_fn <- substName aa nt1 mv2
             ; open_fn  <- openName aa nt1 mv2'
             ; return $ subst_fn ++ "_" ++ open_fn ++ "_var"
             }

      lcHyp nt2 nt2' lc u
          | canBindIn aaa nt2' nt2 = printf "  %s %s ->\n" lc u
          | otherwise              = ""

      neq mv2 mv2' x y | mv2 == mv2' = printf "  %s <> %s ->\n" x y
                       | otherwise   = ""

      gen aa nt1 nt2 mv2 nt2' mv2' =
          do { subst_fn  <- substName aa nt1 mv2
             ; open_fn   <- openName aa nt1 mv2'
             ; u         <- newName nt2
             ; x         <- newName mv2
             ; y         <- newName mv2'
             ; constr    <- getFreeVarConstr aa nt2' mv2'
             ; e         <- newName nt1
             ; lc        <- lcName aa nt2
             ; let stmt = printf "forall %s %s %s %s,\n\
                                 \%s\
                                 \%s\
                                 \  %s %s %s (%s (%s %s) %s) = %s (%s %s) (%s %s %s %s)"
                                 e u x y
                                 (neq mv2 mv2' x y)
                                 (lcHyp nt2 nt2' lc u)
                                 subst_fn u x open_fn (toName constr) y e
                                 open_fn (toName constr) y subst_fn u x e
             ; let rw = subst_fn ++ "_" ++ open_fn
             ; let proof = printf "intros; rewrite %s; %s." rw defaultSimp
             ; return (stmt, proof)
             }

{- | @subst e2 x e1 = open_rec k e2 (close_rec k x e1)@. -}

subst_spec_rec :: ASTAnalysis -> [NtRoot] -> M String
subst_spec_rec aaa nt1s =
    do { thms     <- processNt1Nt2Mv2 aaa nt1s thm
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False Hide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 =
          do { subst_fn <- substName aa nt1 mv2
             ; return $ subst_fn ++ "_spec_rec"
             }

      thm aa nt1 nt2 mv2 =
          do { k        <- newName bvarRoot
             ; e1       <- newName nt1
             ; e2       <- newName nt2
             ; x        <- newName mv2
             ; close_fn <- closeRecName aa nt1 mv2
             ; open_fn  <- openRecName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2
             ; return $ printf "forall %s %s %s %s,\n\
                               \  %s %s %s %s = %s %s %s (%s %s %s %s)"
                        e1 e2 x k
                        subst_fn e2 x e1 open_fn k e2 close_fn k x e1
             }

{- | @subst e2 x e1 = open e2 (close x e1)@. -}

subst_spec :: ASTAnalysis -> [NtRoot] -> M String
subst_spec aaa nt1s =
    do { gens     <- processNt1Nt2Mv2 aaa nt1s gen
       ; names    <- processNt1Nt2Mv2 aaa nt1s name
       ; return $ lemmaText2 Resolve False NoHide [hintDb] names gens
       }
    where
      name aa nt1 _ mv2 =
          do { subst_fn <- substName aa nt1 mv2
             ; return $ subst_fn ++ "_spec"
             }

      gen aa nt1 nt2 mv2 =
          do { e1       <- newName nt1
             ; e2       <- newName nt2
             ; x        <- newName mv2
             ; close_fn <- closeName aa nt1 mv2
             ; open_fn  <- openName aa nt1 mv2
             ; subst_fn <- substName aa nt1 mv2
             ; let stmt = printf "forall %s %s %s,\n\
                                 \  %s %s %s %s = %s %s (%s %s %s)"
                                 e1 e2 x
                                 subst_fn e2 x e1 open_fn e2 close_fn x e1

             ; let proof = printf "unfold %s; unfold %s; %s."
                                  close_fn open_fn defaultSimp
             ; return (stmt, proof)
             }

{- | @subst u y (subst u' x e) = subst (subst u y u') x (subst u y e)@
     when @x `notin` fv u@.

     Implementation note (BEA): The case analysis in the function is
     somewhat intense.  Maybe there's a simpler way? -}

subst_subst :: ASTAnalysis -> [NtRoot] -> M String
subst_subst aaa nt1s =
    do { thms     <- processNt1Nt2Mv2' aaa nt1s thm
       ; names    <- processNt1Nt2Mv2' aaa nt1s name
       ; types    <- processNt1 aaa nt1s ntType
       ; let proof = repeat (mutPfStart Prop types ++ defaultSimp ++ ".")
       ; return $ mutualLemmaText2 Resolve False NoHide [hintDb] Prop names thms proof
       }
    where
      name aa nt1 _ mv2 _ mv2' =
          do { subst_out <- substName aa nt1 mv2
             ; subst_in  <- substName aa nt1 mv2'
             ; return $ subst_out ++ "_" ++ subst_in
             }

      neq x y mv2 mv2' | mv2 == mv2' = "  " ++ x ++ " <> " ++ y ++ " ->\n"
      neq _ _ _   _    | otherwise   = ""

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' && canBindIn aa nt2' nt2 =
          do { subst_out  <- substName aa nt1 mv2
             ; subst_in   <- substName aa nt1 mv2'
             ; subst_new  <- substName aa nt2' mv2
             ; fv_fn      <- fvName aa nt2 mv2'
             ; e          <- newName nt1
             ; u          <- newName nt2
             ; y          <- newName mv2
             ; u'         <- newName nt2'
             ; x          <- newName mv2'
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \  %s %s %s %s ->\n\
                               \%s\
                               \  %s %s %s (%s %s %s %s) = %s (%s %s %s %s) %s (%s %s %s %s)"
                               e u u' x y
                               x mvSetNotin fv_fn u
                               (neq x y mv2 mv2')
                               subst_out u y subst_in u' x e
                               subst_in subst_new u y u' x subst_out u y e
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2 nt2' =
          do { subst_out  <- substName aa nt1 mv2
             ; subst_in   <- substName aa nt1 mv2'
             ; subst_new  <- substName aa nt2' mv2
             ; e          <- newName nt1
             ; u          <- newName nt2
             ; y          <- newName mv2
             ; u'         <- newName nt2'
             ; x          <- newName mv2'
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \%s\
                               \  %s %s %s (%s %s %s %s) = %s (%s %s %s %s) %s (%s %s %s %s)"
                               e u u' x y
                               (neq x y mv2 mv2')
                               subst_out u y subst_in u' x e
                               subst_in subst_new u y u' x subst_out u y e
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | canBindIn aa nt2' nt2 =
          do { subst_out  <- substName aa nt1 mv2
             ; subst_in   <- substName aa nt1 mv2'
             ; fv_fn      <- fvName aa nt2 mv2'
             ; e          <- newName nt1
             ; u          <- newName nt2
             ; y          <- newName mv2
             ; u'         <- newName nt2'
             ; x          <- newName mv2'
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \  %s %s %s %s ->\n\
                               \%s\
                               \  %s %s %s (%s %s %s %s) = %s %s %s (%s %s %s %s)"
                               e u u' x y
                               x mvSetNotin fv_fn u
                               (neq x y mv2 mv2')
                               subst_out u y subst_in u' x e
                               subst_in u' x subst_out u y e
             }

      thm aa nt1 nt2 mv2 nt2' mv2' | otherwise =
          do { subst_out  <- substName aa nt1 mv2
             ; subst_in   <- substName aa nt1 mv2'
             ; e          <- newName nt1
             ; u          <- newName nt2
             ; y          <- newName mv2
             ; u'         <- newName nt2'
             ; x          <- newName mv2'
             ; return $ printf "forall %s %s %s %s %s,\n\
                               \  %s %s %s %s ->\n\
                               \%s\
                               \  %s %s %s (%s %s %s %s) = %s %s %s (%s %s %s %s)"
                               e u u' x y
                               (neq x y mv2 mv2')
                               subst_out u y subst_in u' x e
                               subst_in u' x subst_out u y e
             }
