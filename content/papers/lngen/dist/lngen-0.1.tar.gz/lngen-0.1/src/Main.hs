{- | This module defines the @main@ IO action for this program. -}

module Main where

import Data.Maybe  ( mapMaybe )
import Monad       ( when )
import System      ( getArgs, getProgName )
import System.Console.GetOpt
import System.IO   ( stdout, hFlush, hPutStr )
import Text.Printf ( printf )

import ASTCheck         ( astOfPreAST )
import ComputationMonad ( runM )
import CoqLNOutput      ( coqOfAST )
import MyLibrary        ( getResult )
import Parser           ( parseOttFile )


{- ----------------------------------------------------------------------- -}
{- * Parsing command-line arguments -}

{- | Datatype for command-line flags. -}

data ProgFlag
    = CoqOutput String   -- ^ Destination for Coq output.
    | CoqStdout          -- ^ Send Coq output to standard out.
    | CoqLoadPath String -- ^ The path component of the LoadPath declaration for Coq output.
    | Help               -- ^ Request to display usage information.
    | Merge              -- ^ Request to merge the input files.
    deriving ( Eq )

{- | The usage message for this program.  It depends on the name this
   program was invoked by. -}

usageMsg :: IO String
usageMsg = do { n <- getProgName
              ; let msg = printf "Usage: %s [OPTION1 OPTION2 ...] FILE1 FILE2 ...\n\
                                 \\n\
                                 \Note: Specifying multiple input files makes sense\n\
                                 \only if the '--merge' option is specified.\n"
                                 n
              ; return $ usageInfo msg options
              }

{- | Command-line options. -}

options :: [OptDescr ProgFlag]
options =
    [ Option []    ["coq"]          (ReqArg CoqOutput "FILE")   "destination for Coq output"
    , Option []    ["coq-stdout"]   (NoArg CoqStdout)           "send Coq output to standard out"
    , Option []    ["coq-loadpath"] (ReqArg CoqLoadPath "PATH") "relative path of the metatheory library to the generated output"
    , Option ['?'] ["help"]         (NoArg Help)                "displays usage information"
    , Option []    ["merge"]        (NoArg Merge)               "merge input files (NOT IMPLEMENTED)"
    ]

{- | Processes the command-line arguments to this program.  Returns a
   list of flags and a list of non-options. -}

processArgv :: IO ([ProgFlag], [String])
processArgv =
    do { argv   <- getArgs
       ; usage  <- usageMsg
       ; (o, n) <- case getOpt Permute options argv of
                     (o, n, []) -> return (o, n)
                     (_, _, es) -> error $ concat es ++ "\n" ++ usage
       ; when (Help  `elem` o) (error usage)
       ; when (Merge `elem` o) (error "Merging not implemented.")
       ; return (o, n)
       }

{- | Returns the Coq LoadPath specifications, if any. -}

getCoqLoadPaths :: [ProgFlag] -> [String]
getCoqLoadPaths flags = mapMaybe getCoqLoadPath flags
    where
      getCoqLoadPath (CoqLoadPath s) = Just s
      getCoqLoadPath _               = Nothing


{- ----------------------------------------------------------------------- -}
{- * The \"main\" action -}

{- | The main action for this program. -}

main :: IO ()
main =
    do { (flags, inputNames) <- processArgv
       ; mapM_ (processInput flags) inputNames
       }
    where
      processInput flags file =
          do { preAst <- parseOttFile file
             ; let ast       = getResult (astOfPreAST preAst)
                   coqPaths  = getCoqLoadPaths flags
                   coqOutput = runM $ coqOfAST coqPaths ast
             ; mapM_ (output $! coqOutput) flags
             }

      output coq (CoqOutput f) = writeFile f coq
      output coq (CoqStdout)   = hPutStr stdout coq >> hFlush stdout
      output _   _             = return ()
