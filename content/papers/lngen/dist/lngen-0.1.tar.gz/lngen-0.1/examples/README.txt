Compiling these examples:

- Run 'make' to compile the examples in this directory.  This will
  automatically compile the copy of our library for programming
  language metatheory that resides in metatheory-8.2/


============================================================================

Brief descriptions of the examples:

- Fsub: System F with subtyping

- LF_hhp93: LF, as defined by Harper, Honsell, and Plotkin (1993)

- Lambda: Untyped lambda terms.

- STLC: Simply typed lambda terms.
