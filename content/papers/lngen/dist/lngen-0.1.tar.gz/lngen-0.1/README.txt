Overview of this tool:

This tool parses a subset of the Ott specification language [1] and
outputs definitions, lemmas, and proofs using a locally nameless
encoding.  It aims to generate all the tedious "infrastructure"
associated with a locally nameless encoding.

Additional documentation for this tool can be found in doc/.

[1] http://www.cl.cam.ac.uk/~pes20/ott/

============================================================================

Input and output language descriptions (vague):

- In a list of homomorphisms, only the first instance of each kind is
  used; others are ignored.

- The default implementation type for metavariables in Coq is "string".

- Distinct metavariable declarations are generally treated as being
  distinct, even if they are specified to use the same implementation
  type.  The exceptions to this are the generated "gather" and
  "pick_fresh" tactics.

- We sometimes generate more output than is strictly necessary because
  we treat a non-mutually inductive datatype as a special case of a
  mutually inductive datatype.  We do this in order to simplify the
  implementation of the tool.

============================================================================

Compiling and using this software:

- The sources here are known to compile with GHC 6.8.3 and GHC 6.10.1.
  Other Haskell compilers may work, but the Makefiles are hard-coded
  to use GHC.  See src/README.txt for more about the implementation.

- Run 'make' in this directory or the 'src' directory.  You should be
  left with an executable called 'lngen' in this directory.

- Run 'lngen --help' for a brief description of how to use the
  program.  Sample inputs and outputs are in the examples/ directory,
  as well as a copy of the metatheory library upon which they depend.
  See examples/README.txt for more information about the examples.
