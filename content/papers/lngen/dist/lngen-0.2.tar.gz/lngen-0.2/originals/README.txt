Contextual:
  Code from the paper Formalizing Soundness of Contextual Effects, by
  Polyvios Pratikakis, Jeffrey S. Foster, Michael Hicks and Iulian Neamtiu
  (TPHOLs 2008).  It's been updated to work with Coq 8.2.

Fsub:
  System F with subtyping, extended with let-bindings and sum types.  The
  version here is from Subversion revision 3283 of the metatheory library.
