- The version of ln_transform.ml here is intended to replace the one in the
  src/ directory of the Ott 0.10.16 distribution.  It modifies the locally
  nameless back end to use "universal" quantification for local closure and
  a more general definition of "open", and tweaks the generated tactic
  definitions.
