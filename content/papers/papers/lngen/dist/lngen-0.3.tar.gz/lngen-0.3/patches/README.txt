About this patch
================

This patch  is to  be used  with Ott versions  0.10.16 and  0.10.17.  It
modifies Ott's locally  nameless back end to define  local closure using
"universal" quantification  and to define  a more general  definition of
"open".  It  also modifies the  back end to generate  tactic definitions
that are compatible with the metatheory library used by LNgen.


Applying the patch
==================

In the  Ott source distribution, overwrite  src/ln_transform.ml with the
version in this directory.  Then, (re)build Ott.
